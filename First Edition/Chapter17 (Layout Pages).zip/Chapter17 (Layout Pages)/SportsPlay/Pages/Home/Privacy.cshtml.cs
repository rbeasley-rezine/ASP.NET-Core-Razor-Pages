﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class PrivacyModel : PageModel
    {

        public void OnGet()
        {

            // Set the header data.
            ViewData["Title"] = "Privacy";
            ViewData["User"] = HttpContext.Session.GetString("strUser");
            ViewData["UserStatus"] = HttpContext.Session.GetString("strUserStatus");
            ViewData["MessageColor"] = HttpContext.Session.GetString("strMessageColor");
            ViewData["Message"] = HttpContext.Session.GetString("strMessage");

        }

    }
}
