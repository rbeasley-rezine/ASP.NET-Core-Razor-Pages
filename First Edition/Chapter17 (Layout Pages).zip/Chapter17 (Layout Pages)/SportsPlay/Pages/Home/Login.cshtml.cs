﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class LoginModel : PageModel
    {

        public string EmailAddress { get; set; }
        public string Password { get; set; }

        public void OnGet()
        {

            // Set the header data.
            ViewData["Title"] = "Login";
            ViewData["User"] = HttpContext.Session.GetString("strUser");
            ViewData["UserStatus"] = HttpContext.Session.GetString("strUserStatus");
            ViewData["MessageColor"] = HttpContext.Session.GetString("strMessageColor");
            ViewData["Message"] = HttpContext.Session.GetString("strMessage");

        }

        public RedirectResult OnPostLogin()
        {

            // Log in the user.
            // There are three valid email addresses.
            if (EmailAddress == "rregal@sportsplay.com" && Password == "abc")
            {
                // Save the user's information.
                HttpContext.Session.SetString("strUser", "Richard R Regal");
                HttpContext.Session.SetString("strUserStatus", "M"); // Manager.
                // Set the message.
                HttpContext.Session.SetString("strMessageColor", "Green");
                HttpContext.Session.SetString("strMessage", "You have logged in successfully! Welcome to SportsPlay!");
                return Redirect("Welcome");
            }
            else if (EmailAddress == "bbillingsley@sportsplay.com" && Password == "abc")
            {
                // Save the user's information.
                HttpContext.Session.SetString("strUser", "Beth B Billingsley");
                HttpContext.Session.SetString("strUserStatus", "S"); // Staff.
                // Set the message.
                HttpContext.Session.SetString("strMessageColor", "Green");
                HttpContext.Session.SetString("strMessage", "You have logged in successfully! Welcome to SportsPlay!");
                return Redirect("Welcome");
            }
            else if (EmailAddress == "jjones@somemail.com" && Password == "abc")
            {
                // Save the user's information.
                HttpContext.Session.SetString("strUser", "Jacob J Jones");
                HttpContext.Session.SetString("strUserStatus", "C"); // Customer.
                // Set the message.
                HttpContext.Session.SetString("strMessageColor", "Green");
                HttpContext.Session.SetString("strMessage", "You have logged in successfully! Welcome to SportsPlay!");
                return Redirect("Welcome");
            }
            else
            {
                // Set the message.
                HttpContext.Session.SetString("strMessageColor", "Red");
                HttpContext.Session.SetString("strMessage", "You have entered an invalid email address and password combination. Please try again.");
                return Redirect("Login");
            }

        }

    }
}