﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class WelcomeModel : PageModel
    {

        public void OnGet()
        {

            // Set the header data.
            ViewData["Title"] = "Welcome";
            ViewData["User"] = HttpContext.Session.GetString("strUser");
            ViewData["UserStatus"] = HttpContext.Session.GetString("strUserStatus");
            ViewData["MessageColor"] = HttpContext.Session.GetString("strMessageColor");
            ViewData["Message"] = HttpContext.Session.GetString("strMessage");

        }

    }
}