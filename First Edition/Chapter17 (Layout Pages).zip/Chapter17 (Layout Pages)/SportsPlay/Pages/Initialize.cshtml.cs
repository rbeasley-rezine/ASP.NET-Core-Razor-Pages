﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InitializeModel : PageModel
    {

        public RedirectResult OnGet()
        {

            // Log out the user.
            HttpContext.Session.Clear();

            // Initialize the header data.
            HttpContext.Session.SetString("strUser", "*");
            HttpContext.Session.SetString("strUserStatus", "*");
            HttpContext.Session.SetString("strMessageColor", "Green");
            HttpContext.Session.SetString("strMessage", "Please log in.");
            return Redirect("Home/Login");

        }

    }
}
