﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class DateAndTimeOperationsModel : PageModel
    {

        public void OnGet()
        {

            DateRelatedProperties();
            DateRelatedMethods();
            DateFormatting();
            DateParsing();
            TimeRelatedProperties();
            TimeRelatedMethods();
            TimeFormatting();

        }

        protected void DateRelatedProperties()
        {

            // Get the date. The time part of the date defaults to
            // 12:00:00 AM because we are only asking for the date.
            string strDate = DateTime.Today.ToString();
            // strDate = "4/3/2020 12:00:00 AM"

            // Get the year.
            int intYear = DateTime.Today.Year;
            // intYear = 2020

            // Get the month.
            int intMonth = DateTime.Today.Month;
            // intMonth = 4

            // Get the day.
            int intDay = DateTime.Today.Day;
            // intDay = 3

            // Get the day of the week.
            string strDayOfWeek = DateTime.Today.DayOfWeek.ToString();
            // strDayOfWeek = "Friday"

            // Get the day of the year.
            int intDayOfYear = DateTime.Today.DayOfYear;
            // intDayOfYear = 94

        }

        protected void DateRelatedMethods()
        {

            // Create a new current DateTime structure.
            DateTime datDateCurrent = new DateTime();
            // Assign today's date to the current DateTime structure.
            datDateCurrent = DateTime.Today;
            // datDateTimeCurrent = {4/3/2020 12:00:00 AM}

            // Declare a new date string.
            string strDateNew = "";
            // strDateNew = ""

            // Add 1 year to the current date.
            strDateNew = datDateCurrent.AddYears(1).ToString();
            // strDateNew = "4/3/2021 12:00:00 AM"

            // Add 3 months to the current date.
            strDateNew = datDateCurrent.AddMonths(3).ToString();
            // strDateNew = "7/3/2020 12:00:00 AM"

            // Add 5 days to the current date.
            strDateNew = datDateCurrent.AddDays(5).ToString();
            // strDateNew = "4/8/2020 12:00:00 AM"

            // Compare the current date to the first-of-year date.
            // Less than zero = The current date is earlier than the first-of-year
            // date.
            // Zero = The current date is the same as the first-of-year date.
            // Greater than zero = The current date is later than the first-of-year
            // date.
            DateTime datDateFirstOfYear = new DateTime(2020, 01, 01);
            int intResult = datDateCurrent.CompareTo(datDateFirstOfYear);
            // intResult = 1

            // Check to see if daylight saving time is in effect.
            bool booDaylightSavingTime = datDateCurrent.IsDaylightSavingTime();
            // booDaylightSavingTime = true

            // Check to see if this is a leap year.
            bool booLeapYear = DateTime.IsLeapYear(datDateCurrent.Year);
            // booLeapYear = true

            // Determine how many days have elapsed since the first-of-year date.
            TimeSpan timTimeSpan = datDateCurrent.Subtract(datDateFirstOfYear);
            int intDifferenceDays = timTimeSpan.Days;
            // intDifferenceDays = 93

        }

        protected void DateFormatting()
        {

            // Declare a new date string.
            string strDateNew = "";

            // Format the date as a long date.
            strDateNew = DateTime.Today.ToLongDateString();
            // strDateNew = "Friday, April 3, 2020"

            // Format the date as a short date.
            strDateNew = DateTime.Today.ToShortDateString();
            // strDateNew = "4/3/2020"

            // Customize the date using format specifiers.
            strDateNew = DateTime.Today.ToString("yyyy.MM.dd");
            // strDateNew = "2020.04.03"

            // Customize the date using format specifiers.
            strDateNew = DateTime.Today.ToString("dddd, MMMM dd, yyyy g");
            // strDateNew = "Friday, April 03, 2020 A.D."

        }

        protected void DateParsing()
        {

            // Declare the DateTime structure and variables.
            DateTime datDate = new DateTime();
            string strDate = "";
            bool booSuccessful = false;

            // Attempt to parse a valid date (with dashes) from a string.
            // Check to make sure the parse was successful.
            strDate = "02-28-2019";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2019 12:00:00 AM}, booSuccessful = true

            // Attempt to parse a valid date (with slashes) from a string.
            // Check to make sure the parse was successful.
            strDate = "02/28/2019";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2019 12:00:00 AM}, booSuccessful = true

            // Attempt to parse a valid date (written out) from a string.
            // Check to make sure the parse was successful.
            strDate = "February 28, 2019";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2019 12:00:00 AM}, booSuccessful = true

            // Attempt to parse an invalid date from a string. Check to make
            // sure the parse was successful.
            strDate = "02-29-2019";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {1/1/0001 12:00:00 AM}, booSuccessful = false

        }

        protected void TimeRelatedProperties()
        {

            // Get the date and time.
            string strDateTime = DateTime.Now.ToString();
            // strDateTime = "4/3/2020 10:09:08 AM"

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2020, 4, 3, 15, 30, 25);
            // datTimeCurrent = {4/3/2020 3:30:25 PM}

            // Get the time of day.
            string strTimeOfDay = datTimeCurrent.TimeOfDay.ToString();
            // strTimeOfDay = "15:30:25"

            // Get the hour.
            int intHour = datTimeCurrent.Hour;
            // intHour = 15

            // Get the minute.
            int intMinute = datTimeCurrent.Minute;
            // intMinute = 30

            // Get the second.
            int intSecond = datTimeCurrent.Second;
            // intSecond = 25

        }

        protected void TimeRelatedMethods()
        {

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2020, 4, 3, 15, 30, 25);
            // datTimeCurrent = {4/3/2020 3:30:25 PM}

            // Declare a new time string.
            string strTimeNew = "";
            // strTimeNew = ""

            // Add 2 hours to the current time.
            strTimeNew = datTimeCurrent.AddHours(2).ToString();
            // strTimeNew = "4/3/2020 5:30:25 PM"

            // Add 4 minutes to the current time.
            strTimeNew = datTimeCurrent.AddMinutes(4).ToString();
            // strTimeNew = "4/3/2020 3:34:25 PM"

            // Add 6 seconds to the current time.
            strTimeNew = datTimeCurrent.AddSeconds(6).ToString();
            // strTimeNew = "4/3/2020 3:30:31 PM"

            // Compare the first time to the second time.
            // Less than zero = The first time is earlier than the second time.
            // Zero = The first is the same as the second time.
            // Greater than zero = The first time is later than the second time.
            DateTime datTimeFirst = new DateTime(2020, 4, 3, 12, 25, 30);
            DateTime datTimeSecond = new DateTime(2020, 4, 3, 11, 30, 25);
            int intResult = datTimeFirst.CompareTo(datTimeSecond);
            // intResult = 1

            // Determine how many hours, minutes, and seconds have elapsed
            // since the first-of-year date and time.
            DateTime datDateTimeFirstOfYear = new DateTime(2020, 01, 01, 0, 0, 0);
            DateTime datDateTimeCurrent = new DateTime();
            datDateTimeCurrent = DateTime.Now;
            // datDateTimeCurrent = {4/3/2020 4:38:30 PM}
            TimeSpan timTimeSpan = datDateTimeCurrent.Subtract(datDateTimeFirstOfYear);
            double douDifferenceHours = timTimeSpan.TotalHours;
            // douDifferenceHours = 2248.6418198635
            double douDifferenceMinutes = timTimeSpan.TotalMinutes;
            // douDifferenceMinutes = 134918.50919181
            double douDifferenceSeconds = timTimeSpan.TotalSeconds;
            // douDifferenceSeconds = 8095110.5515086

        }

        protected void TimeFormatting()
        {

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2020, 4, 3, 15, 30, 25);
            // datTimeCurrent = {4/3/2020 3:30:25 PM}

            // Declare a new time string.
            string strTimeNew = "";
            // strTimeNew = ""

            // Format the time as a long time.
            strTimeNew = datTimeCurrent.ToLongTimeString();
            // strTimeNew = "3:30:25 PM"

            // Format the time as a short time.
            strTimeNew = datTimeCurrent.ToShortTimeString();
            // strTimeNew = "3:30 PM"

            // Customize the time format.
            // The result is strange.
            strTimeNew = datTimeCurrent.ToString("HH Hours mm Minutes ss Seconds");
            // strTimeNew = "15 15our25 30 4inuPe25 25 Secon325"

            // Customize the time format using single quotes.
            // The result is better.
            strTimeNew = datTimeCurrent.ToString("HH 'Hours' mm 'Minutes' ss 'Seconds'");
            // strTimeNew = "15 Hours 30 Minutes 25 Seconds"

            // Customize the time format.
            // Commented out since an exception is thrown. Uncomment when testing.
            // strTimeNew = datTimeCurrent.ToString("h:mm O'clock tt");
            // A format exception is thrown. Cannot find a matching quote character
            // for the character '''.

            // Customize the time format using an escape sequence.
            strTimeNew = datTimeCurrent.ToString("h:mm 'O\\'clock' tt");
            // strTimeNew = "3:30 O'clock PM"

        }

    }
}