﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class ImgModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public string ImageName { get; set; }
        public string AlternateText { get; set; }

        public string Src;
        public string Alt;

        public void OnGet()
        {
        }

        public void OnPostDisplay()
        {

            if (ImageName != null)
            {
                // Display the image.
                Src = "\\images\\" + ImageName;
                Alt = AlternateText;
                // Set the message.
                MessageColor = "Green";
                Message = "You have displayed the product image successfully!";
            }
            else
            {
                // Set the message.
                MessageColor = "Red";
                Message = "Please enter a product image and try again.";
            }

        }

    }
}