﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class InputFileModel : PageModel
    {

        private readonly IWebHostEnvironment IWebHostEnvironment;
        public InputFileModel(IWebHostEnvironment IWHE)
        {
            IWebHostEnvironment = IWHE;
        }

        public string MessageColor;
        public string Message;

        public IFormFile ProductImage { get; set; }

        public void OnGet()
        {
        }

        public void OnPostUpload()
        {

            if (ProductImage != null)
            {
                // Upload the file.
                string strImagesPath = Path.Combine(IWebHostEnvironment.WebRootPath, "images");
                string strFileName = Path.GetFileName(ProductImage.FileName);
                string strFilePath = Path.Combine(strImagesPath, strFileName);
                FileStream objFileStream = new FileStream(strFilePath, FileMode.Create);
                ProductImage.CopyTo(objFileStream);
                objFileStream.Close();
                // Set the message.
                MessageColor = "Green";
                Message = "You have uploaded the product image successfully!";
            }
            else
            {
                // Set the message.
                MessageColor = "Red";
                Message = "Please select a product image to upload and try again.";
            }

        }

    }
}