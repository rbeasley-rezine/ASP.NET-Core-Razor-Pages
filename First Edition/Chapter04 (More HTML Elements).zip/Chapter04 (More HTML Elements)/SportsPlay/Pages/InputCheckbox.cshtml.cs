﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class InputCheckboxModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public bool Footwear { get; set; }
        public bool Clothing { get; set; }
        public bool TennisEquipment { get; set; }

        public void OnGet()
        {
        }

        public void OnPostSet()
        {

            // Build the message.
            if (Footwear)
            {
                Message = Message + "Footwear ";
            }
            if (Clothing)
            {
                Message = Message + "Clothing ";
            }
            if (TennisEquipment)
            {
                Message = Message + "Tennis Equipment ";
            }

            // Set the message.
            MessageColor = "Green";
            Message = "You have chosen to filter your search on the following: " + Message;

        }

    }
}