﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class TextareaModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public string ProductDescription { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            // Set the message.
            MessageColor = "Green";
            Message = "You have added [" + ProductDescription + "] successfully!";

        }

    }
}