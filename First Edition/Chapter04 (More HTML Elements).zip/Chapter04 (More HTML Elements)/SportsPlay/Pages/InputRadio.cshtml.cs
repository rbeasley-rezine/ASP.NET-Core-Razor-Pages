﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class InputRadioModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public string Shipper { get; set; }

        public void OnGet()
        {
        }

        public void OnPostSelect()
        {

            // Build the message.
            if (Shipper == "FedEx")
            {
                Message = "Federal Express";
            }
            else if (Shipper == "UPS")
            {
                Message = "United Parcel Service";
            }
            else if (Shipper == "USPS")
            {
                Message = "United States Postal Service";
            }

            // Set the message.
            MessageColor = "Green";
            Message = "You have selected " + Message + " as your shipper.";

        }

    }
}