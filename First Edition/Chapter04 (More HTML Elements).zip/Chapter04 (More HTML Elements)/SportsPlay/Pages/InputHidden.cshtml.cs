﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class InputHiddenModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int EmployeeId { get; set; }

        public void OnGet()
        {
        }

        public void OnPostDisplay()
        {

            // Set the employee ID.
            EmployeeId = 7;

            // Set the message.
            MessageColor = "Green";
            Message = "You have displayed Employee ID " + EmployeeId + ".";

        }

    }
}