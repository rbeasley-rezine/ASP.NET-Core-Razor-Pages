﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay.Pages.Products
{
    public class MaintainProductsModel : PageModel
    {

        public string MessageColor;
        public string Message;

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public MaintainProductsModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public class JoinResult
        {
            public string Category;
            public string Supplier;
            public int ProductId;
            public string Product;
        }

        public IList<JoinResult> JoinResultIList;

        public async Task OnGetAsync()
        {

            // Set the message.
            MessageColor = TempData["strMessageColor"].ToString();
            Message = TempData["strMessage"].ToString();

            // Retrieve the rows for display.
            JoinResultIList = await (
                from p in SportsPlayContext.Product
                join c in SportsPlayContext.Category on p.CategoryId equals c.CategoryId
                join s in SportsPlayContext.Supplier on p.SupplierId equals s.SupplierId
                orderby c.Category1, s.Supplier1, p.Product1
                select new JoinResult
                {
                    Category = c.Category1,
                    Supplier = s.Supplier1,
                    ProductId = p.ProductId,
                    Product = p.Product1
                })
                .ToListAsync();

        }

    }
}