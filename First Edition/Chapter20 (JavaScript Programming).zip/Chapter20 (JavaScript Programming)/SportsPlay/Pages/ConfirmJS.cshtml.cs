﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class ConfirmJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}