﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class ImgJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}