﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputDateJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}