﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputTimeJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}