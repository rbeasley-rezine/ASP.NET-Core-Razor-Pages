﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class ValidationJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}