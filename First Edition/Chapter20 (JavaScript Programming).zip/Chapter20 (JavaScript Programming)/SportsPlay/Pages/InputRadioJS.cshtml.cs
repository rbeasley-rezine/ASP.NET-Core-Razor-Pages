﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputRadioJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}