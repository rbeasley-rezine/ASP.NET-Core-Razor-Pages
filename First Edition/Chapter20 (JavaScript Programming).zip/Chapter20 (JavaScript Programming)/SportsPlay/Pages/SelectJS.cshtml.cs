﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class SelectJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}