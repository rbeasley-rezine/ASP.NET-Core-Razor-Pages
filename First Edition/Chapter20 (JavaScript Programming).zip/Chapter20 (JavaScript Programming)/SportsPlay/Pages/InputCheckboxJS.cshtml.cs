﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputCheckboxJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}