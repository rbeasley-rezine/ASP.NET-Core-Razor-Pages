﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class AlertJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}