﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputHiddenJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}