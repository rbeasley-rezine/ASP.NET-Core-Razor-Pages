﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class BasicJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}