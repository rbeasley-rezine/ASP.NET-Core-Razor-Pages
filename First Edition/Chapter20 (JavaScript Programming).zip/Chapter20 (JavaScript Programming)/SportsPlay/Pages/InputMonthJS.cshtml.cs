﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputMonthJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}