﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class TextareaJSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}