﻿// These are all the data validation functions. New ones can be added
// as needed.

function ValidateRange(strValue, strErrorMessage, decMinimum, decMaximum) {

    strValue = strValue.trim();
    if (strValue != "") {
        if (!isNaN(strValue) && strValue >= decMinimum && strValue <= decMaximum) {
            return "";
        }
        else {
            var strMessage = strErrorMessage + "\n";
            return strMessage;
        }
    }
    else {
        return "";
    }

}

function ValidateRegularExpression(strValue, strErrorMessage, strRegularExpression) {

    strValue = strValue.trim();
    if (strValue != "") {
        var objRegExp = new RegExp(strRegularExpression);
        if (objRegExp.test(strValue)) {
            return "";
        }
        else {
            var strMessage = strErrorMessage + "\n";
            return strMessage;
        }
    }
    else {
        return "";
    }

}

function ValidateRequired(strValue, strErrorMessage) {

    strValue = strValue.trim();
    if (strValue != "") {
        return "";
    }
    else {
        var strMessage = strErrorMessage + "\n";
        return strMessage;
    }

}
