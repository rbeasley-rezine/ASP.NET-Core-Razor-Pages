﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class ConfirmProductQueryStringParametersModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public int SupplierId { get; set; }
        public string Product { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public decimal Price { get; set; }
        public byte NumberInStock { get; set; }
        public byte NumberOnOrder { get; set; }
        public byte ReorderLevel { get; set; }

        public void OnGet()
        {

            // Get the query string parameters.
            CategoryId = Convert.ToInt32(HttpContext.Request.Query["intCategoryId"]);
            SupplierId = Convert.ToInt32(HttpContext.Request.Query["intSupplierId"]);
            Product = HttpContext.Request.Query["strProduct"];
            Description = HttpContext.Request.Query["strDescription"];
            Image = HttpContext.Request.Query["strImage"];
            Price = Convert.ToDecimal(HttpContext.Request.Query["decPrice"]);
            NumberInStock = Convert.ToByte(HttpContext.Request.Query["bytNumberInStock"]);
            NumberOnOrder = Convert.ToByte(HttpContext.Request.Query["bytNumberOnOrder"]);
            ReorderLevel = Convert.ToByte(HttpContext.Request.Query["bytReorderLevel"]);

        }

    }
}