﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class LoginSessionVariablesModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public string EmailAddress { get; set; }
        public string Password { get; set; }

        public void OnGet()
        {
        }

    public RedirectResult OnPostLogin()
    {

        // Log in the user by simulating a database lookup.
        if (EmailAddress == "rregal@sportsplay.com" && Password == "abc")
        {
            // Assume that the lookup returns the following attribute values
            // from the database. Notice that the attribute names would not
            // begin with a type (according to our standards).
            int EmployeeId = 2;
            string LastName = "Regal";
            string FirstName = "Richard";
            string MiddleInitial = "R";
            string Status = "M";
            // Format the status.
            if (Status == "M")
            {
                Status = "Manager";
            }
            else
            {
                Status = "Staff";
            }
            // Format the user information.
            string strUser = FirstName + " " + MiddleInitial + " " + LastName + " (" + Status + ")";
            // Set the session variables.
            // Session State must be configured in Startup.cs.
            HttpContext.Session.SetString("intEmployeeId", EmployeeId.ToString());
            HttpContext.Session.SetString("strUser", strUser);
            // Go to the Welcome page.
            return Redirect("WelcomeSessionVariables");
        }
        else
        {
            // Set the message.
            MessageColor = "Red";
            Message = "You have entered an invalid email address and password combination. Please try again.";
            return null;
        }

    }

    }
}