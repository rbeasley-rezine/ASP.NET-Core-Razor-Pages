﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class AddProductQueryStringParametersModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public int SupplierId { get; set; }
        public string Product { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public decimal Price { get; set; }
        public byte NumberInStock { get; set; }
        public byte NumberOnOrder { get; set; }
        public byte ReorderLevel { get; set; }

        public void OnGet()
        {
        }

        public RedirectResult OnPostConfirm()
        {

            // Set the query string parameters.
            // Go to the confirmation page.
            return Redirect("ConfirmProductQueryStringParameters" +
                "?intCategoryId=" + CategoryId +
                "&intSupplierId=" + SupplierId +
                "&strProduct=" + Product +
                "&strDescription=" + Description +
                "&strImage=" + Image +
                "&decPrice=" + Price +
                "&bytNumberInStock=" + NumberInStock +
                "&bytNumberOnOrder=" + NumberOnOrder +
                "&bytReorderLevel=" + ReorderLevel
                );

        }

    }
}