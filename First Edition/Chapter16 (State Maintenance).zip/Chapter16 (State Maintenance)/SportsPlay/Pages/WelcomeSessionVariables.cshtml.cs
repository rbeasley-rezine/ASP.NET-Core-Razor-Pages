﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class WelcomeSessionVariablesModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public void OnGet()
        {

            // Get the session variables.
            // Session State must be configured in Startup.cs.
            int intEmployeeId = Convert.ToInt32(HttpContext.Session.GetString("intEmployeeId"));
            string strUser = HttpContext.Session.GetString("strUser");
            MessageColor = "Green";
            Message = "You have logged in successfully as " + strUser + "! Welcome to SportsPlay!";

        }

    }
}