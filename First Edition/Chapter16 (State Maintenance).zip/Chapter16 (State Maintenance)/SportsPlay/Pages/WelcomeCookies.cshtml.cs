﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class WelcomeCookiesModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public void OnGet()
        {

            // Get the cookies.
            int intEmployeeId = Convert.ToInt32(Request.Cookies["intEmployeeId"]);
            string strUser = Request.Cookies["strUser"];
            MessageColor = "Green";
            Message = "You have logged in successfully as " + strUser + "! Welcome to SportsPlay!";

        }

    }
}