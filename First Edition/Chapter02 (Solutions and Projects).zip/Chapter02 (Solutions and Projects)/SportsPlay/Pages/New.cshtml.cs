﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class NewModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}