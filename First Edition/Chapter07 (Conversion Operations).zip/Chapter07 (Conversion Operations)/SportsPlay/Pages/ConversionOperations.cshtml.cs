﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class ConversionOperationsModel : PageModel
    {

        public string Input { get; set; }

        public void OnGet()
        {

            WideningConversions();
            NarrowingConversions();
            ConvertClassConversions();

        }

        protected void WideningConversions()
        {

            // Implicitly convert an 8-bit unsigned integer to a 16-bit unsigned
            // integer.
            byte bytNumber = 100;
            ushort ushNumber = 0;
            ushNumber = bytNumber;
            // ushNumber = 100

            // Implicitly convert a 32-bit signed integer to a 64-bit signed
            // integer.
            int intNumber = -123;
            long lonNumber = 0;
            lonNumber = intNumber;
            // lonNumber = -123

            // Implicitly convert an 8-bit signed integer to a single-precision
            // (32-bit) floating-point number.
            sbyte sbyNumber = -12;
            float floNumber = 0f;
            floNumber = sbyNumber;
            // floNumber = -12

            // Implicitly convert a single-precision (32-bit) floating-point
            // number to a double-precision (64-bit) floating-point number.
            float floNumberSmaller = 12345.6789f;
            double douNumberLarger = 0;
            douNumberLarger = floNumberSmaller;
            // douNumberLarger = 12345.6787109375

            // Implicitly convert the variable types in the expression before
            // evaluating the expression.
            double douNumber1 = 3;
            short shoNumber2 = 7;
            short shoNumber3 = 12;
            double douAverage = 0;
            douAverage = (douNumber1 + shoNumber2 + shoNumber3) / 3;
            // douAverage = 7.33...

        }

        protected void NarrowingConversions()
        {

            // Explicitly convert (i.e., cast) a 16-bit unsigned integer to an 8-bit
            // unsigned integer.
            ushort ushNumber = 100;
            byte bytNumber = 0;
            bytNumber = (byte)ushNumber;
            // bytNumber = 100

            // Explicitly convert (i.e., cast) a 64-bit signed integer to a 32-bit
            // signed integer.
            long lonNumber = -123;
            int intNumber = 0;
            intNumber = (int)lonNumber;
            // intNumber = -123

            // Explicitly convert (i.e., cast) a decimal (128-bit) value to a
            // double-precision (64-bit) floating-point number.
            decimal decNumber = 123.45m;
            double douNumber = 0;
            douNumber = (double)decNumber;
            // douNumber = 123.45

            // Explicitly convert (i.e., cast) a single-precision (32-bit)
            // floating-point number to an 8-bit signed integer.
            float floNumber = -12.50f;
            sbyte sbyNumber = 0;
            sbyNumber = (sbyte)floNumber;
            // sbyNumber = -12

            // Explicitly convert (i.e., cast) a 16-bit signed integer to an 8-bit
            // unsigned integer.
            short shoNumberSigned = -100;
            byte bytNumberUnsigned = 0;
            bytNumberUnsigned = (byte)shoNumberSigned;
            // bytNumberUnsigned = 156

            // Explicitly convert (i.e., cast) a 16-bit unsigned integer to an 8-bit
            // unsigned integer that is too large to fit.
            ushort ushNumberTooLarge = 65535;
            byte bytNumberTooSmall = 0;
            bytNumberTooSmall = (byte)ushNumberTooLarge;
            // bytNumberTooSmall = 255

        }

        protected void ConvertClassConversions()
        {

            // Convert the 8-bit unsigned integer to its equivalent Unicode
            // (16-bit) character.
            byte bytNumber = 65;
            char[] chaUnicodeCharacter = new char[1];
            chaUnicodeCharacter[0] = Convert.ToChar(bytNumber);
            // chaUnicodeCharacter[0] = "A"

            // Convert the DateTime structure to its equivalent immutable,
            // fixed-length string of Unicode characters.
            DateTime datDateTime = DateTime.Today;
            string strDateTime = "";
            strDateTime = Convert.ToString(datDateTime);
            // strDateTime = "4/2/2020 12:00:00 AM"

            // Convert the 8-bit signed integer to its equivalent 16-bit
            // unsigned integer.
            sbyte sbyReorderLevel = 33;
            ushort ushReorderLevel = 0;
            ushReorderLevel = Convert.ToUInt16(sbyReorderLevel);
            // ushReorderLevel = 33

            // Convert the single-precision (32-bit) floating-point number to its
            // equivalent double-precision (64-bit) floating-point number.
            float floAmount = 7.1234f;
            double douAmount = 0;
            douAmount = Convert.ToDouble(floAmount);
            // douAmount = 7.1234002113342285

            // Convert the 32-bit signed integer to its equivalent Boolean
            // value (true or false).
            int intFlag = 1;
            bool booFlag = false;
            booFlag = Convert.ToBoolean(intFlag);
            // booFlag = true

            // Convert the immutable, fixed-length string of Unicode characters
            // to its equivalent 8-bit unsigned integer.
            string strAge = "3";
            byte bytAge = 0;
            bytAge = Convert.ToByte(strAge);
            // bytAge = 3

            // Convert the immutable, fixed-length string of Unicode characters
            // to its equivalent DateTime structure.
            string strDateTimeToday = "4/2/2020";
            DateTime datDateTimeToday = new DateTime();
            datDateTimeToday = Convert.ToDateTime(strDateTimeToday);
            // datDateTimeToday = {4/2/2020 12:00:00 AM}

            // Convert the 16-bit unsigned integer to its equivalent 8-bit
            // signed integer.
            ushort ushNumberOnOrder = 100;
            sbyte sbyNumberOnOrder = 0;
            sbyNumberOnOrder = Convert.ToSByte(ushNumberOnOrder);
            // sbyNumberOnOrder = 100

            // Convert the double-precision (64-bit) floating-point number to
            // its equivalent single-precision (32-bit) floating-point number.
            double douRefund = -123.45;
            float floRefund = 0;
            floRefund = Convert.ToSingle(douRefund);
            // floRefund = -123.45

            // Convert the decimal (128-bit) value to its equivalent 16-bit
            // signed integer.
            decimal decNumberInStock = 122.5m;
            short shoNumberInStock = 0;
            shoNumberInStock = Convert.ToInt16(decNumberInStock);
            // shoNumberInStock = 122

        }

    }
}