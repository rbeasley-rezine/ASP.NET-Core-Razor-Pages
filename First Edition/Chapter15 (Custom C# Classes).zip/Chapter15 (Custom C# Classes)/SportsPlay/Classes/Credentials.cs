﻿using System;

namespace SportsPlay.Classes
{
    public static class Credentials
    {

        public static string GenerateEmailAddress(string strFirstName, string strLastName)
        {

            // Generate an email address. The person’s email address is
            // composed of his or her first initial and last name followed
            // by @sportsplay.com.
            string strEmailAddress = strFirstName.Substring(0, 1).ToLower() + strLastName.ToLower() + "@sportsplay.com";
            return strEmailAddress;

        }

        public static string GeneratePassword(string strFirstName, string strLastName)
        {

            // Generate a password. The person’s password is composed
            // of his or her first and last initials followed by five
            // randomly-generated characters.
            string strFirstNameInitial = strFirstName.Substring(0, 1).ToLower();
            string strLastNameInitial = strLastName.Substring(0, 1).ToLower();
            string strPassword = strFirstNameInitial + strLastNameInitial;
            Random objRandom = new Random();
            for (int i = 1; i <= 5; i++)
            {
                short shoRandomNumber = (short)objRandom.Next(1, 10);
                switch (shoRandomNumber)
                {
                    case 1:
                        strPassword = strPassword + "1";
                        break;
                    case 2:
                        strPassword = strPassword + "2";
                        break;
                    case 3:
                        strPassword = strPassword + "3";
                        break;
                    case 4:
                        strPassword = strPassword + "4";
                        break;
                    case 5:
                        strPassword = strPassword + "5";
                        break;
                    case 6:
                        strPassword = strPassword + "!";
                        break;
                    case 7:
                        strPassword = strPassword + "#";
                        break;
                    case 8:
                        strPassword = strPassword + "$";
                        break;
                    case 9:
                        strPassword = strPassword + "%";
                        break;
                    case 10:
                        strPassword = strPassword + "*";
                        break;
                }
            }
            return strPassword;

        }

    }
}
