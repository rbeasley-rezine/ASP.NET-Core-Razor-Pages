﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Classes;

namespace SportsPlay.Pages
{
    public class InstantiateEmployeeModel : PageModel
    {

        public void OnGet()
        {

            // Initialize the variables associated with the employee.
            string strLastName = "Okon";
            string strFirstName = "Dawn";
            string strMiddleInitial = "R";
            string strAddress = "6785 New Jersey Road";
            string strCity = "Bradenton";
            string strState = "FL";
            string strZipCode = "48321";
            string strPhone = "734-987-1234";
            string strEmailAddress = "";
            string strPassword = "";
            string strStatus = "s";

            // Create an Employee object from the Employee class.
            Employee objEmployee = new Employee();

            // Generate an email address for the employee.
            strEmailAddress = objEmployee.GenerateEmailAddress(strFirstName, strLastName);

            // Generate a password for the employee.
            strPassword = objEmployee.GeneratePassword(strFirstName, strLastName);

            // Set the properties of the Employee object.
            objEmployee.LastName = strLastName;
            objEmployee.FirstName = strFirstName;
            objEmployee.MiddleInitial = strMiddleInitial;
            objEmployee.Address = strAddress;
            objEmployee.City = strCity;
            objEmployee.State = strState;
            objEmployee.ZipCode = strZipCode;
            objEmployee.Phone = strPhone;
            objEmployee.EmailAddress = strEmailAddress;
            objEmployee.Password = strPassword;
            objEmployee.Status = strStatus;

            // Get the properties from the Employee object.
            string strLastName2 = objEmployee.LastName;
            // strLastName2 = "Okon"
            string strFirstName2 = objEmployee.FirstName;
            // strFirstName2 = "Dawn"
            string strMiddleInitial2 = objEmployee.MiddleInitial;
            // strMiddleInitial2 = "R"
            string strAddress2 = objEmployee.Address;
            // strAddress2 = "6785 New Jersey Road"
            string strCity2 = objEmployee.City;
            // strCity2 = "Bradenton"
            string strState2 = objEmployee.State;
            // strState2 = "FL"
            string strZipCode2 = objEmployee.ZipCode;
            // strZipCode2 = "48321"
            string strPhone2 = objEmployee.Phone;
            // strPhone2 = "734-987-1234"
            string strEmailAddress2 = objEmployee.EmailAddress;
            // strEmailAddress2 = "dokon@sportsplay.com"
            string strPassword2 = objEmployee.Password;
            // strPassword2 = "do#5323"
            string strStatus2 = objEmployee.Status;
            // strStatus2 = "s"

        }

    }
}