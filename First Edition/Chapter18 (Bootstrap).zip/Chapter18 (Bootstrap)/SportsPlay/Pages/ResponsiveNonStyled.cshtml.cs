﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class ResponsiveNonStyledPageModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int EmployeeId { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Please enter a last name.")]
        public string LastName { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Please enter a first name.")]
        public string FirstName { get; set; }

        [Display(Name = "Middle Initial")]
        public string MiddleInitial { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Please enter an address.")]
        public string Address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Please enter a city.")]
        public string City { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Please select a state.")]
        public string State { get; set; }

        [Display(Name = "Zip Code")]
        [Required(ErrorMessage = "Please enter a zip code.")]
        public string ZipCode { get; set; }

        [Display(Name = "Phone")]
        [Required(ErrorMessage = "Please enter a phone.")]
        public string Phone { get; set; }

        [Display(Name = "Email Address")]
        [Required(ErrorMessage = "Please enter an email address.")]
        public string EmailAddress { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Please enter a password.")]
        public string Password { get; set; }

        [Display(Name = "Status")]
        [Required(ErrorMessage = "Please select a status.")]
        public string Status { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            // Set the message.
            MessageColor = "Green";
            Message = FirstName + " " + MiddleInitial + " " + LastName + " was successfully added.";

        }

        public void OnPostCancel()
        {

            // Set the message.
            MessageColor = "Red";
            Message = "The operation was cancelled. No data was affected.";

        }

    }
}