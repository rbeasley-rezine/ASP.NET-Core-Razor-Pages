﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.IO;

namespace SportsPlay.Pages
{
    public class FileSystemOperationsModel : PageModel
    {

        private readonly IWebHostEnvironment IWebHostEnvironment;
        public FileSystemOperationsModel(IWebHostEnvironment IWHE)
        {
            IWebHostEnvironment = IWHE;
        }

        public void OnGet()
        {

            //CreateFile();
            //WriteToFile();
            //ReadFromFile();
            //GetAndSetPropertiesAndAttributesOfFile();
            //CopyFile();
            //DeleteFile();

        }

        protected void CreateFile()
        {

            // Create the file.
            string strMessage = "";
            string strFileName = "Contract_Adidas.txt";
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFilePath = Path.Combine(strContractsPath, strFileName);
            if (System.IO.File.Exists(strFilePath))
            {
                strMessage = "That file already exists.";
            }
            else
            {
                System.IO.File.Create(strFilePath);
                strMessage = "Contract file successfully created.";
            }
            // strMessage = "Contract file successfully created."

        }

        protected void WriteToFile()
        {

            // Write to the file.
            string strFileName = "Contract_Adidas.txt";
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFilePath = Path.Combine(strContractsPath, strFileName);
            string strContract = "";
            strContract = "AGREEMENT BETWEEN SportsPlay AND Adidas" + Environment.NewLine + Environment.NewLine;
            strContract += "This Deed of Agreement is made and entered into on the 4th day of July 20xx" + Environment.NewLine + Environment.NewLine;
            strContract += "BETWEEN" + Environment.NewLine + Environment.NewLine;
            strContract += "SportsPlay, Inc. (hereinafter referred to as the PURCHASER)" + Environment.NewLine + Environment.NewLine;
            strContract += "AND" + Environment.NewLine + Environment.NewLine;
            strContract += "Adidas, Inc. (hereinafter referred to as the SUPPLIER).";
            System.IO.File.AppendAllText(strFilePath, strContract);

        }

        protected void ReadFromFile()
        {

            // Read from the file.
            string strFileName = "Contract_Adidas.txt";
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFilePath = Path.Combine(strContractsPath, strFileName);
            string strContract = "";
            strContract = System.IO.File.ReadAllText(strFilePath);
            // strContract =
            // AGREEMENT BETWEEN SportsPlay AND Adidas
            // 
            // This Deed of Agreement is made and entered into on the 4th day
            // of July 20xx
            // 
            // BETWEEN
            // 
            // SportsPlay, Inc. (hereinafter referred to as the PURCHASER)
            // 
            // AND
            // 
            // Adidas, Inc. (hereinafter referred to as the SUPPLIER).

        }

        protected void GetAndSetPropertiesAndAttributesOfFile()
        {

            // Get and set the attributes and properties of the file.
            string strFileName = "Contract_Adidas.txt";
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFilePath = Path.Combine(strContractsPath, strFileName);

            // Get the date and time properties of the file.
            DateTime datCreated = System.IO.File.GetCreationTime(strFilePath);
            DateTime datModified = System.IO.File.GetLastWriteTime(strFilePath);
            DateTime datAccessed = System.IO.File.GetLastAccessTime(strFilePath);

            // Set the date and time properties of the file.
            System.IO.File.SetCreationTime(strFilePath, DateTime.Now);
            System.IO.File.SetLastWriteTime(strFilePath, DateTime.Now);
            System.IO.File.SetLastAccessTime(strFilePath, DateTime.Now);

            // Get the read-only and hidden attributes of the file.
            FileAttributes fiaFileAttributes = System.IO.File.GetAttributes(strFilePath);
            bool booReadOnly = (fiaFileAttributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly;
            bool booHidden = (fiaFileAttributes & FileAttributes.Hidden) == FileAttributes.Hidden;

            // Toggle (i.e., make opposite) the read-only and hidden attributes of
            // the file based on their current state.
            if (booReadOnly && booHidden)
            {
                // Make file not read-only and not hidden.
                System.IO.File.SetAttributes(strFilePath, FileAttributes.Normal | FileAttributes.Normal);
            }
            else if (booReadOnly && !booHidden)
            {
                // Make file not read-only and hidden.
                System.IO.File.SetAttributes(strFilePath, FileAttributes.Normal | FileAttributes.Hidden);
            }
            else if (!booReadOnly && booHidden)
            {
                // Make file read-only and not hidden.
                System.IO.File.SetAttributes(strFilePath, FileAttributes.ReadOnly | FileAttributes.Normal);
            }
            else
            {
                // Make file read-only and hidden.
                System.IO.File.SetAttributes(strFilePath, FileAttributes.ReadOnly | FileAttributes.Hidden);
            }

        }

        protected void CopyFile()
        {

            // Make a copy of the file.
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFileName = "Contract_Adidas.txt";
            string strFileNameCopy = "Contract_Adidas_Copy.txt";
            string strFileNamePath = Path.Combine(strContractsPath, strFileName);
            string strFileNamePathCopy = Path.Combine(strContractsPath, strFileNameCopy);
            System.IO.File.Copy(strFileNamePath, strFileNamePathCopy);

        }

        protected void DeleteFile()
        {

            // Delete the file.
            string strMessage = "";
            string strFileName = "Contract_Adidas.txt";
            string strContractsPath = Path.Combine(IWebHostEnvironment.WebRootPath, "contracts");
            string strFilePath = Path.Combine(strContractsPath, strFileName);
            if (System.IO.File.Exists(strFilePath))
            {
                System.IO.File.Delete(strFilePath);
                strMessage = "Contract file successfully deleted.";
            }
            else
            {
                strMessage = "Contract file NOT successfully deleted.";
            }
            // strMessage = "Contract file successfully deleted."

        }

    }
}