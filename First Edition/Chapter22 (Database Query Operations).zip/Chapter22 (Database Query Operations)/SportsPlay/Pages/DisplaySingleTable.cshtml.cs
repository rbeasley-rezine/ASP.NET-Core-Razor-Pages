﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class DisplaySingleTableModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public DisplaySingleTableModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public IList<Product> ProductIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display.
            ProductIList = await (
                from p in SportsPlayContext.Product
                orderby p.Product1
                select p)
                .ToListAsync();

        }

    }
}