﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class FilterSelectModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public FilterSelectModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        [BindProperty]
        public int CategoryId { get; set; }
        public SelectList CategorySelectList;

        public class JoinResult
        {
            public int CategoryId;
            public string Category;
            public string Supplier;
            public string Product;
            public string Image;
            public decimal? Price;
        }

        public IList<JoinResult> JoinResultIList;

        private IQueryable<JoinResult> JoinResultIQueryable;

        public async Task OnGetAsync()
        {

            PopulateSelectList();
            await RetrieveRowsForDisplay();

        }

        public async Task OnPostFilterAsync()
        {

            PopulateSelectList();
            await RetrieveRowsForDisplay();

        }

        private void PopulateSelectList()
        {

            // Populate the select list.
            CategorySelectList = new SelectList(SportsPlayContext.Category
                .OrderBy(c => c.Category1), "CategoryId", "Category1");

        }

        private async Task RetrieveRowsForDisplay()
        {

            // Define the database query.
            JoinResultIQueryable = (
                from p in SportsPlayContext.Product
                join c in SportsPlayContext.Category on p.CategoryId equals c.CategoryId
                join s in SportsPlayContext.Supplier on p.SupplierId equals s.SupplierId
                orderby c.Category1, s.Supplier1, p.Product1
                select new JoinResult
                {
                    CategoryId = c.CategoryId,
                    Category = c.Category1,
                    Supplier = s.Supplier1,
                    Product = p.Product1,
                    Image = p.Image,
                    Price = p.Price,
                });

            // If a filter option was selected, modify the database query.
            if (CategoryId != 0)
            {
                JoinResultIQueryable = JoinResultIQueryable
                    .Where(jr => jr.CategoryId == CategoryId);
            }

            // Retrieve the rows for display.
            JoinResultIList = await JoinResultIQueryable
                .ToListAsync();

        }

    }
}