﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class DisplayMultipleTablesSortingModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public DisplayMultipleTablesSortingModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public string SortCategory;
        public string SortSupplier;
        public string SortProduct;
        public string SortImage;
        public string SortPrice;

        public class JoinResult
        {
            public string Category;
            public string Supplier;
            public string Product;
            public string Image;
            public decimal? Price;
        }

        public IList<JoinResult> JoinResultIList;

        private IQueryable<JoinResult> JoinResultIQueryable;

        public async Task OnGetAsync(string strSortOrder)
        {

            // Define the database query.
            JoinResultIQueryable = (
                from p in SportsPlayContext.Product
                join c in SportsPlayContext.Category on p.CategoryId equals c.CategoryId
                join s in SportsPlayContext.Supplier on p.SupplierId equals s.SupplierId
                select new JoinResult
                {
                    Category = c.Category1,
                    Supplier = s.Supplier1,
                    Product = p.Product1,
                    Image = p.Image,
                    Price = p.Price,
                });

            // Modify the database query.
            switch (strSortOrder)
            {
                case null:
                case "Category ASC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderBy(jr => jr.Category)
                        .ThenBy(jr => jr.Supplier)
                        .ThenBy(jr => jr.Product);
                    break;
                case "Category DESC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderByDescending(jr => jr.Category)
                        .ThenByDescending(jr => jr.Supplier)
                        .ThenByDescending(jr => jr.Product);
                    break;
                case "Supplier ASC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderBy(jr => jr.Supplier)
                        .ThenBy(jr => jr.Product);
                    break;
                case "Supplier DESC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderByDescending(jr => jr.Supplier)
                        .ThenByDescending(jr => jr.Product);
                    break;
                case "Product ASC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderBy(jr => jr.Product);
                    break;
                case "Product DESC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderByDescending(jr => jr.Product);
                    break;
                case "Image ASC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderBy(jr => jr.Image);
                    break;
                case "Image DESC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderByDescending(jr => jr.Image);
                    break;
                case "Price ASC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderBy(jr => jr.Price);
                    break;
                case "Price DESC":
                    JoinResultIQueryable = JoinResultIQueryable
                        .OrderByDescending(jr => jr.Price);
                    break;
            }

            // Set the next sort order.
            if (strSortOrder == "Category ASC" || strSortOrder == null)
            {
                SortCategory = "Category DESC";
            }
            else
            {
                SortCategory = "Category ASC";
            }
            if (strSortOrder == "Supplier ASC")
            {
                SortSupplier = "Supplier DESC";
            }
            else
            {
                SortSupplier = "Supplier ASC";
            }
            if (strSortOrder == "Product ASC")
            {
                SortProduct = "Product DESC";
            }
            else
            {
                SortProduct = "Product ASC";
            }
            if (strSortOrder == "Image ASC")
            {
                SortImage = "Image DESC";
            }
            else
            {
                SortImage = "Image ASC";
            }
            if (strSortOrder == "Price ASC")
            {
                SortPrice = "Price DESC";
            }
            else
            {
                SortPrice = "Price ASC";
            }

            // Retrieve the rows for display.
            JoinResultIList = await JoinResultIQueryable
                .ToListAsync();

        }

    }
}