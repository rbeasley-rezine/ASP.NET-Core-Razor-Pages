﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class DisplayMultipleTablesModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public DisplayMultipleTablesModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public class JoinResult
        {
            public string Category;
            public string Supplier;
            public string Product;
            public string Image;
            public decimal? Price;
        }

        public IList<JoinResult> JoinResultIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display.
            JoinResultIList = await (
                from p in SportsPlayContext.Product
                join c in SportsPlayContext.Category on p.CategoryId equals c.CategoryId
                join s in SportsPlayContext.Supplier on p.SupplierId equals s.SupplierId
                orderby c.Category1, s.Supplier1, p.Product1
                select new JoinResult
                {
                    Category = c.Category1,
                    Supplier = s.Supplier1,
                    Product = p.Product1,
                    Image = p.Image,
                    Price = p.Price,
                })
                .ToListAsync();

        }

    }
}