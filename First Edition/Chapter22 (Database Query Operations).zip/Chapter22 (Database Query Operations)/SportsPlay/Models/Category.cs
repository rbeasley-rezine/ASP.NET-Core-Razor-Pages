﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Models
{
    public partial class Category
    {
        public Category()
        {
            Product = new HashSet<Product>();
        }

        [Display (Name = "Category")]
        public int CategoryId { get; set; }
        public string Category1 { get; set; }

        public virtual ICollection<Product> Product { get; set; }
        public decimal Price { get; internal set; }
    }
}
