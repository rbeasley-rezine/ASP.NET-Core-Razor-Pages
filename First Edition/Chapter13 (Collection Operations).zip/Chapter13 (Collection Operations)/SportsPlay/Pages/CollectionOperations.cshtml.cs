﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace SportsPlay.Pages
{
    public class CollectionOperationsModel : PageModel
    {

        public void OnGet()
        {

            Stack();
            Queue();
            LinkedList();
            SortedList();

        }

        protected void Stack()
        {

            // Declare the stack.
            Stack<string> strProductStack = new Stack<string>();

            // Declare the outputs.
            int intCount = 0;
            string strProduct = "";

            // Add items to the stack.
            strProductStack.Push("Nike Men's Summer Flex Ace 7 Inch Short");
            strProductStack.Push("Nike Men's Summer RF Premier Jacket");
            strProductStack.Push("Nike Zoom Vapor 9.5 Tour");
            strProductStack.Push("Babolat Pure Aero French Open");
            // strProductStack [0] = "Babolat Pure Aero French Open" (Top)
            // strProductStack [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductStack [2] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [3] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

            // Get the number of items in the stack.
            intCount = strProductStack.Count;
            // intCount = 4

            // See what the next item on the stack is without removing it.
            strProduct = strProductStack.Peek();
            // strProduct = "Babolat Pure Aero French Open"
            // strProductStack [0] = "Babolat Pure Aero French Open" (Top)
            // strProductStack [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductStack [2] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [3] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

            // Remove an item from the stack.
            strProduct = strProductStack.Pop();
            // strProduct = "Babolat Pure Aero French Open"
            // strProductStack [0] = "Nike Zoom Vapor 9.5 Tour" (Top)
            // strProductStack [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [2] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

            // Clear the stack.
            strProductStack.Clear();
            // strProductStack = empty

        }

        protected void Queue()
        {

            // Declare the queue.
            Queue<string> strProductQueue = new Queue<string>();

            // Declare the outputs.
            int intCount = 0;
            string strProduct = "";

            // Add items to the queue.
            strProductQueue.Enqueue("Nike Men's Summer Flex Ace 7 Inch Short");
            strProductQueue.Enqueue("Nike Men's Summer RF Premier Jacket");
            strProductQueue.Enqueue("Nike Zoom Vapor 9.5 Tour");
            strProductQueue.Enqueue("Babolat Pure Aero French Open");
            // strProductQueue [0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beginning)
            // strProductQueue [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductQueue [2] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [3] = "Babolat Pure Aero French Open" (End)

            // Get the number of items in the queue.
            intCount = strProductQueue.Count;
            // intCount = 4

            // See what the next item in the queue is without removing it.
            strProduct = strProductQueue.Peek();
            // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
            // strProductQueue [0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beginning)
            // strProductQueue [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductQueue [2] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [3] = "Babolat Pure Aero French Open" (End)

            // Remove an item from the queue.
            strProduct = strProductQueue.Dequeue();
            // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
            // strProductQueue [0] = "Nike Men's Summer RF Premier Jacket" (Beginning)
            // strProductQueue [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [2] = "Babolat Pure Aero French Open" (End)

            // Clear the queue.
            strProductQueue.Clear();
            // strProductQueue = empty

        }

        protected void LinkedList()
        {

            // Declare the linked list.
            LinkedList<string> strSupplierLinkedList = new LinkedList<string>();

            // Declare a linked list node.
            LinkedListNode<string> llnCurrentNode;

            // Declare the outputs.
            int intCount = 0;
            string strSupplier = "";
            bool booFound = false;

            // Add a node to the start of the linked list.
            strSupplierLinkedList.AddFirst("Adidas");
            // strSupplierLinkedList [0] = "Adidas" (Start and End)

            // Add a node after the first node in the linked list.
            llnCurrentNode = strSupplierLinkedList.First;
            strSupplierLinkedList.AddAfter(llnCurrentNode, "Babolat");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat" (End)

            // Add a node after the current node in the linked list.
            llnCurrentNode = strSupplierLinkedList.Find("Babolat");
            strSupplierLinkedList.AddAfter(llnCurrentNode, "Nike");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Nike" (End)

            // Add a node before the specified node in the linked list.
            llnCurrentNode = strSupplierLinkedList.Find("Nike");
            strSupplierLinkedList.AddBefore(llnCurrentNode, "Head");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Head"
            // strSupplierLinkedList [3] = "Nike" (End)

            // Add a node to the end of the linked list.
            strSupplierLinkedList.AddLast("Prince");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Head"
            // strSupplierLinkedList [3] = "Nike"
            // strSupplierLinkedList [4] = "Prince" (End)

            // Get the number of nodes in the linked list.
            intCount = strSupplierLinkedList.Count;
            // intCount = 5

            // Get the value of the first node of the linked list.
            strSupplier = strSupplierLinkedList.First.Value;
            // strSupplier = "Adidas"

            // Get the value of the last node of the linked list.
            strSupplier = strSupplierLinkedList.Last.Value;
            // strSupplier = "Prince"

            // Determine whether or not a value exists in the linked list.
            booFound = strSupplierLinkedList.Contains("Nike");
            // booFound = true

            // Find the first node in the linked list that contains the
            // specified value.
            llnCurrentNode = strSupplierLinkedList.Find("Head");
            // llnCurrentNode = [3]

            // Find the first node in the linked list that contains the specified
            // value. The specified value is not in the list.
            llnCurrentNode = strSupplierLinkedList.Find("xyz");
            // llnCurrentNode = null

            // Remove the node at the start of the linked list.
            strSupplierLinkedList.RemoveFirst();
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Head"
            // strSupplierLinkedList [2] = "Nike"
            // strSupplierLinkedList [3] = "Prince" (End)

            // Remove the node at the end of the linked list.
            strSupplierLinkedList.RemoveLast();
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Head"
            // strSupplierLinkedList [2] = "Nike" (End)

            // Remove the first occurrence of the specified value from the
            // linked list.
            strSupplierLinkedList.Remove("Head");
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Nike" (End)

            // Clear the linked list.
            strSupplierLinkedList.Clear();
            // strSupplierLinkedList = empty

        }

        protected void SortedList()
        {

            // Declare the sorted list.
            SortedList<string, string> strShipperSortedList = new SortedList<string, string>();

            // Declare the outputs.
            int intCount = 0;
            string strShipper = "";
            bool booFound = false;

            // Add key-value pairs to the sorted list.
            strShipperSortedList.Add("FedEx", "Federal Express");
            strShipperSortedList.Add("DHL", "Dalsey, Hillblom, and Lynn");
            strShipperSortedList.Add("UPS", "United Parcel Service");
            strShipperSortedList.Add("USPS", "Un St Po Se");
            // strShipperSortedList [0] = {[DHL, Dalsey, Hillblom, and Lynn]} (Start)
            // strShipperSortedList [1] = {[FedEx, Federal Express]
            // strShipperSortedList [2] = {[UPS, United Parcel Service]}
            // strShipperSortedList [3] = {[USPS, Un St Po Se]} (End)

            // Get the number of elements in the sorted list.
            intCount = strShipperSortedList.Count;
            // intCount = 4

            // Set the value associated with a specific key in the sorted list.
            strShipperSortedList["USPS"] = "United States Postal Service";
            // strShipperSortedList [0] = {[DHL, Dalsey, Hillblom, and Lynn]} (Start)
            // strShipperSortedList [1] = {[FedEx, Federal Express]
            // strShipperSortedList [2] = {[UPS, United Parcel Service]}
            // strShipperSortedList [3] = {[USPS, United States Postal Service]} (End)

            // Get the value associated with a specific key in the sorted list.
            strShipper = strShipperSortedList["FedEx"];
            // strShipper = "Federal Express"

            // Determine whether or not the sorted list contains a specific key.
            booFound = strShipperSortedList.ContainsKey("UPS");
            // booFound = true

            // Determine whether or not the sorted list contains a specific value.
            booFound = strShipperSortedList.ContainsValue("United Parcel Service");
            // booFound = true

            // Remove the element with the specified key from the sorted list.
            strShipperSortedList.Remove("DHL");
            // strShipperSortedList [0] = {[FedEx, Federal Express] (Start)
            // strShipperSortedList [1] = {[UPS, United Parcel Service]}
            // strShipperSortedList [2] = {[USPS, United States Postal Service]} (End)

            // Clear the sorted list.
            strShipperSortedList.Clear();
            // strShipperSortedList = empty

        }

    }
}