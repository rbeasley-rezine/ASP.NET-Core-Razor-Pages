﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class TableModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}