﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class FormModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}