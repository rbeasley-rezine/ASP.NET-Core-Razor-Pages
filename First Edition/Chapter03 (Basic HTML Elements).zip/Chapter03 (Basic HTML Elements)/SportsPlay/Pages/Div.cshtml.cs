﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class DivModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}