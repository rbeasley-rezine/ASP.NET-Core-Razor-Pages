﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class LabelModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}