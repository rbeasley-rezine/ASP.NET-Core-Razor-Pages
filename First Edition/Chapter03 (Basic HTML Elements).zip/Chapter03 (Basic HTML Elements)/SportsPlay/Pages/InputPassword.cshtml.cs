﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputPasswordModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}