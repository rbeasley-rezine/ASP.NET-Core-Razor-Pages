﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputCheckboxCSSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}