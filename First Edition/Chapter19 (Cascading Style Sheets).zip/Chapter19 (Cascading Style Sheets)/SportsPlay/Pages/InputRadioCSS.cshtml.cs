﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class InputRadioCSSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}