﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class InputTimeCSSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}