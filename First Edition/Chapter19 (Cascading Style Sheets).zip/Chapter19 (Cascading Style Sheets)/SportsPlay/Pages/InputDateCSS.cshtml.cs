﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class InputDateCSSModel : PageModel
    {

        public void OnGet()
        {
        }

    }
}