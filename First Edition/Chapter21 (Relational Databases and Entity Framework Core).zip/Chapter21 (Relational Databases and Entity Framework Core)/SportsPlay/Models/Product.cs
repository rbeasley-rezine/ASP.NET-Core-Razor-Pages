﻿using System.Collections.Generic;

namespace SportsPlay.Models
{
    public partial class Product
    {
        public Product()
        {
            OrderLine = new HashSet<OrderLine>();
        }

        public int ProductId { get; set; }
        public int? CategoryId { get; set; }
        public int? SupplierId { get; set; }
        public string Product1 { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public decimal? Price { get; set; }
        public byte? NumberInStock { get; set; }
        public byte? NumberOnOrder { get; set; }
        public byte? ReorderLevel { get; set; }

        public virtual Category Category { get; set; }
        public virtual Supplier Supplier { get; set; }
        public virtual ICollection<OrderLine> OrderLine { get; set; }
    }
}
