﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class QueryJoinThreeTablesModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public QueryJoinThreeTablesModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public class JoinResult
        {
            public string Category;
            public string Supplier;
            public string Product;
            public decimal? Price;
        }

        public IList<JoinResult> JoinResultIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display (LINQ query syntax).
            JoinResultIList = await (
                from p in SportsPlayContext.Product
                join c in SportsPlayContext.Category on p.CategoryId equals c.CategoryId
                join s in SportsPlayContext.Supplier on p.SupplierId equals s.SupplierId
                where p.Price >= 100
                orderby c.Category1, s.Supplier1, p.Price
                select new JoinResult
                {
                    Category = c.Category1,
                    Supplier = s.Supplier1,
                    Product = p.Product1,
                    Price = p.Price
                })
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in JoinResultIList)
            {
                Debug.WriteLine(
                    "[" + item.Category + "][" + item.Supplier + "]" +
                    "[" + item.Product + "][" + item.Price + "]");
            }

            // Retrieve the rows for display (LINQ method syntax).
            JoinResultIList = await SportsPlayContext.Product
                .Join(SportsPlayContext.Category, p => p.CategoryId, c => c.CategoryId, (p, c) => new { p, c })
                .Join(SportsPlayContext.Supplier, pc => pc.p.SupplierId, s => s.SupplierId, (pc, s) => new JoinResult
                {
                    Category = pc.c.Category1,
                    Supplier = s.Supplier1,
                    Product = pc.p.Product1,
                    Price = pc.p.Price
                })
                .Where(p => p.Price >= 100)
                .OrderBy(c => c.Category)
                .ThenBy(s => s.Supplier)
                .ThenBy(p => p.Price)
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in JoinResultIList)
            {
                Debug.WriteLine(
                    "[" + item.Category + "][" + item.Supplier + "]" +
                    "[" + item.Product + "][" + item.Price + "]");
            }

        }

    }
}