﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Models;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class MaintainUpdateModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public MaintainUpdateModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        private Product Product;

        public async Task OnGetAsync()
        {

            // Retrieve the row from the table.
            Product = await SportsPlayContext.Product.FindAsync(1086);

            // Set the properties of the row.
            Product.Price = 349.00m;
            Product.NumberInStock = 3;

            // Modify the row in the table.
            SportsPlayContext.Product.Update(Product);
            await SportsPlayContext.SaveChangesAsync();

        }

    }
}