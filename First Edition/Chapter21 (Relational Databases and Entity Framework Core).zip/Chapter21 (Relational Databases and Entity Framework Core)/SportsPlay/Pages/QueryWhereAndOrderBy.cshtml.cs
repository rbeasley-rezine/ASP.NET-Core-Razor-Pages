﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class QueryWhereAndOrderByModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public QueryWhereAndOrderByModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public class Product
        {
            public int? CategoryId;
            public string Product1;
            public byte? NumberInStock;
            public byte? ReorderLevel;
        }

        public IList<Product> ProductIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display (LINQ query syntax).
            ProductIList = await (
                from p in SportsPlayContext.Product
                where p.CategoryId == 2
                   && p.NumberInStock <= p.ReorderLevel
                orderby p.Product1
                select new Product
                {
                    CategoryId = p.CategoryId,
                    Product1 = p.Product1,
                    NumberInStock = p.NumberInStock,
                    ReorderLevel = p.ReorderLevel
                })
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in ProductIList)
            {
                Debug.WriteLine(
                    "[" + item.CategoryId + "][" + item.Product1 + "]" +
                    "[" + item.NumberInStock + "][" + item.ReorderLevel + "]");
            }

            // Retrieve the rows for display (LINQ method syntax).
            ProductIList = await SportsPlayContext.Product
                .Select(p => new Product
                {
                    CategoryId = p.CategoryId,
                    Product1 = p.Product1,
                    NumberInStock = p.NumberInStock,
                    ReorderLevel = p.ReorderLevel
                })
                .Where(p => p.CategoryId == 2
                         && p.NumberInStock <= p.ReorderLevel)
                .OrderBy(p => p.Product1)
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in ProductIList)
            {
                Debug.WriteLine(
                    "[" + item.CategoryId + "][" + item.Product1 + "]" +
                    "[" + item.NumberInStock + "][" + item.ReorderLevel + "]");
            }

        }

    }
}