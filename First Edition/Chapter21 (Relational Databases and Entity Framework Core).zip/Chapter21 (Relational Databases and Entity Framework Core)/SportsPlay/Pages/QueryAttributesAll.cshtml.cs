﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SportsPlay.Models;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class QueryAttributesAllModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public QueryAttributesAllModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public IList<Supplier> SupplierIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display (LINQ query syntax).
            SupplierIList = await (
                from s in SportsPlayContext.Supplier
                select s)
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in SupplierIList)
            {
                Debug.WriteLine(
                    "[" + item.SupplierId + "][" + item.Supplier1 + "]" +
                    "[" + item.PointOfContact + "][" + item.Address + "]" +
                    "[" + item.City + "][" + item.State + "]" +
                    "[" + item.ZipCode + "][" + item.Phone + "]" +
                    "[" + item.EmailAddress + "]");
            }

            // Retrieve the rows for display (LINQ method syntax).
            SupplierIList = await SportsPlayContext.Supplier
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in SupplierIList)
            {
                Debug.WriteLine(
                    "[" + item.SupplierId + "][" + item.Supplier1 + "]" +
                    "[" + item.PointOfContact + "][" + item.Address + "]" +
                    "[" + item.City + "][" + item.State + "]" +
                    "[" + item.ZipCode + "][" + item.Phone + "]" +
                    "[" + item.EmailAddress + "]");
            }

        }

    }
}