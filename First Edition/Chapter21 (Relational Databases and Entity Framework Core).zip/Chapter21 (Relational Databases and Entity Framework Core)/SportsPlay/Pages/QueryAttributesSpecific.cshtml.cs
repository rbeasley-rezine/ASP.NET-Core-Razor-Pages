﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class QueryAttributesSpecificModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public QueryAttributesSpecificModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public class Supplier
        {
            public string Supplier1;
            public string PointOfContact;
            public string Phone;
            public string EmailAddress;
        }

        public IList<Supplier> SupplierIList;

        public async Task OnGetAsync()
        {

            // Retrieve the rows for display (LINQ query syntax).
            SupplierIList = await (
                from s in SportsPlayContext.Supplier
                select new Supplier
                {
                    Supplier1 = s.Supplier1,
                    PointOfContact = s.PointOfContact,
                    Phone = s.Phone,
                    EmailAddress = s.EmailAddress
                })
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in SupplierIList)
            {
                Debug.WriteLine(
                    "[" + item.Supplier1 + "][" + item.PointOfContact + "]" +
                    "[" + item.Phone + "][" + item.EmailAddress + "]");
            }

            // Retrieve the rows for display (LINQ method syntax).
            SupplierIList = await SportsPlayContext.Supplier
                .Select(s => new Supplier
                {
                    Supplier1 = s.Supplier1,
                    PointOfContact = s.PointOfContact,
                    Phone = s.Phone,
                    EmailAddress = s.EmailAddress
                })
                .ToListAsync();

            // Display the results in the Output window.
            foreach (var item in SupplierIList)
            {
                Debug.WriteLine(
                    "[" + item.Supplier1 + "][" + item.PointOfContact + "]" +
                    "[" + item.Phone + "][" + item.EmailAddress + "]");
            }

        }

    }
}