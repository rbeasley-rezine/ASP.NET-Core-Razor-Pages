﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Models;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class MaintainDeleteModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public MaintainDeleteModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        private Product Product;

        public async Task OnGetAsync()
        {

            // Retrieve the row from the table.
            Product = await SportsPlayContext.Product.FindAsync(1086);

            // Delete the row from the table.
            SportsPlayContext.Product.Remove(Product);
            await SportsPlayContext.SaveChangesAsync();

        }

    }
}