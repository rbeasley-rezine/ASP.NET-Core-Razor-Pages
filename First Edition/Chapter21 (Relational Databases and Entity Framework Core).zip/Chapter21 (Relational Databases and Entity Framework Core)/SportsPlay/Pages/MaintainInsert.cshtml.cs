﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Models;
using System.Threading.Tasks;

namespace SportsPlay
{
    public class MaintainInsertModel : PageModel
    {

        private readonly SportsPlay.Models.SportsPlayContext SportsPlayContext;
        public MaintainInsertModel(SportsPlay.Models.SportsPlayContext SPC)
        {
            SportsPlayContext = SPC;
        }

        public async Task OnGetAsync()
        {

            // Create a new row.
            Product Product = new Product();

            // Set the properties of the row.
            Product.CategoryId = 3;
            Product.SupplierId = 6;
            Product.Product1 = "Babolat PLAY Pure Aero";
            Product.Description = "Babolat adds PLAY Technology to the Pure Aero! This stick....";
            Product.Image = "BPPA.jpg";
            Product.Price = 249.00m;
            Product.NumberInStock = 2;
            Product.NumberOnOrder = 0;
            Product.ReorderLevel = 1;

            // Add the row to the table.
            SportsPlayContext.Product.Add(Product);
            await SportsPlayContext.SaveChangesAsync();

        }

    }
}