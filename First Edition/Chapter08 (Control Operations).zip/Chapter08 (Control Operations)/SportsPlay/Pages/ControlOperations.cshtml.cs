﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    public class ControlOperationsModel : PageModel
    {

        public void OnGet()
        {

            IfStructure();
            IfElseStructure();
            IfElseIfStructure();
            NestedIfStructure();
            SwitchStructure();
            SwitchThroughStructure();
            WhileStructure();
            DoWhileStructure();
            ForStructure();
            ForEachStructure();
            BreakStatement();
            ContinueStatement();

        }

        protected void IfStructure()
        {

            // This is a relational operator example.

            // Declare the variables.
            const double douDiscountRateSenior = 0.10;
            double douSubtotal = 100.00;
            byte bytCustomerAge = 55;

            // If the customer is 55 or older, apply the senior discount.
            if (bytCustomerAge >= 55)
            {
                douSubtotal = douSubtotal * (1 - douDiscountRateSenior);
            }
            // douSubtotal = 90

            // This is an equality operator example.

            // Declare the variables.
            int intProductId = 5;
            string strMessage = "";

            // If the Product ID is 2, put out a message.
            if (intProductId == 2)
            {
                strMessage = "Sorry. That product is currently on backorder.";
            }
            // strMessage = ""

            // This is a logical AND operator example.

            // Declare the variables.
            byte bytNumberInStock = 4;
            byte bytNumberOnOrder = 0;
            byte bytReorderLevel = 5;
            bool booReorderProduct = false;

            // If the number in stock is less than or equal to the reorder level,
            // and if there is nothing already on order, then set the number on
            // order to the reorder level and indicate that the product should be
            // reordered.
            if (bytNumberInStock <= bytReorderLevel && bytNumberOnOrder == 0)
            {
                bytNumberOnOrder = bytReorderLevel;
                booReorderProduct = true;
            }
            // bytNumberOnOrder = 5, booReorderProduct = true

            // This is a logical OR operator example.

            // Declare the variables.
            string strZipCode = "46131";
            bool booDeliveryAvailable = false;

            // If the zip code is 46131 or 46132, indicate that delivery
            // is available.
            if (strZipCode == "46131" || strZipCode == "46132")
            {
                booDeliveryAvailable = true;
            }
            // booDeliveryAvailable = true

        }

        protected void IfElseStructure()
        {

            // Declare the variables.
            const double douSalesTaxRate = 0.7;
            double douSubtotal = 100.00;
            double douTotal = 0;
            string strState = "OH";

            // Only apply sales tax if the customer resides in Indiana.
            if (strState == "IN")
            {
                douTotal = douSubtotal + (douSalesTaxRate * 10);
            }
            else
            {
                douTotal = douSubtotal;
            }
            // douTotal = 100

        }

        protected void IfElseIfStructure()
        {

            // Declare the variables.
            const double douDiscountRateStandard = 0.10;
            const double douDiscountRateSelect = 0.20;
            const double douDiscountRatePreferred = 0.30;
            double douSubtotal = 100;
            string strCustomerType = "Select";

            // Apply the discount rate based on the type of customer.
            if (strCustomerType == "Standard")
            {
                douSubtotal = douSubtotal * (1 - douDiscountRateStandard);
            }
            else if (strCustomerType == "Select")
            {
                douSubtotal = douSubtotal * (1 - douDiscountRateSelect);
            }
            else if (strCustomerType == "Preferred")
            {
                douSubtotal = douSubtotal * (1 - douDiscountRatePreferred);
            }
            else
            {
                // Do not apply a discount.
            }
            // douSubtotal = 80

        }

        protected void NestedIfStructure()
        {

            // Declare the variables.
            const double douDiscountRateSenior = 0.10;
            const double douDiscountRateStandard = 0.10;
            const double douDiscountRateSelect = 0.20;
            const double douDiscountRatePreferred = 0.30;
            double douSubtotal = 100;
            byte bytCustomerAge = 60;
            string strCustomerType = "Preferred";

            // If the customer is 55 or older, apply the senior discount.
            if (bytCustomerAge >= 55)
            {
                // Apply the discount rate based on the type of customer.
                if (strCustomerType == "Standard")
                {
                    douSubtotal = douSubtotal * (1 - (douDiscountRateStandard + douDiscountRateSenior));
                }
                else if (strCustomerType == "Select")
                {
                    douSubtotal = douSubtotal * (1 - (douDiscountRateSelect + douDiscountRateSenior));
                }
                else if (strCustomerType == "Preferred")
                {
                    douSubtotal = douSubtotal * (1 - (douDiscountRatePreferred + douDiscountRateSenior));
                }
                else
                {
                    // Do not apply a discount.
                }
            }
            else
            {
                // Apply the discount rate based on the type of customer.
                if (strCustomerType == "Standard")
                {
                    douSubtotal = douSubtotal * (1 - douDiscountRateStandard);
                }
                else if (strCustomerType == "Select")
                {
                    douSubtotal = douSubtotal * (1 - douDiscountRateSelect);
                }
                else if (strCustomerType == "Preferred")
                {
                    douSubtotal = douSubtotal * (1 - douDiscountRatePreferred);
                }
                else
                {
                    // Do not apply a discount.
                }
            }
            // douSubtotal = 60

        }

        protected void SwitchStructure()
        {

            // Declare the variables.
            const double douDiscountRateStandard = 0.10;
            const double douDiscountRateSelect = 0.20;
            const double douDiscountRatePreferred = 0.30;
            double douSubtotal = 100;
            string strCustomerType = "Standard";

            // Apply the discount rate based on the type of customer.
            switch (strCustomerType)
            {
                case "Standard":
                    douSubtotal = douSubtotal * (1 - douDiscountRateStandard);
                    break;
                case "Select":
                    douSubtotal = douSubtotal * (1 - douDiscountRateSelect);
                    break;
                case "Preferred":
                    douSubtotal = douSubtotal * (1 - douDiscountRatePreferred);
                    break;
                default:
                    // Do not apply a discount.
                    break;
            }
            // douSubtotal = 90

        }

        protected void SwitchThroughStructure()
        {

            // Declare the variables.
            double douSubtotal = 100;
            double douDiscountRate = 0;
            byte bytNumberOfOrderLines = 5;

            // If the customer purchases 1-3 items, do not apply a discount.
            // If the customer purchases 4-6 items, apply a 10% discount.
            // If the customer purchases 7-9 items, apply a 20% discount.
            // If the customer purchases 10 or more items, apply a 30% discount.
            switch (bytNumberOfOrderLines)
            {
                case 1:
                case 2:
                case 3:
                    // Do not apply a discount.
                    break;
                case 4:
                case 5:
                case 6:
                    douDiscountRate = 0.10;
                    break;
                case 7:
                case 8:
                case 9:
                    douDiscountRate = 0.20;
                    break;
                default:
                    douDiscountRate = 0.30;
                    break;
            }
            douSubtotal = douSubtotal * (1 - douDiscountRate);
            // douSubtotal = 90, douDiscountRate = 0.1

        }

        protected void WhileStructure()
        {

            // Define an array of customers.
            string[] strCustomerArray = new string[] { "Davis, Dan", "Jones, Jerry", "Smith, Sally" };
            short shoIndex = 0;
            string strCustomerList = "";

            // Add customers to the customer list while shoIndex is less than or
            // equal to 2.
            while (shoIndex <= 2)
            {
                strCustomerList = strCustomerList + strCustomerArray[shoIndex] + "; ";
                shoIndex++;
            }
            // strCustomerList = "Davis, Dan; Jones, Jerry; Smith, Sally; "

        }

        protected void DoWhileStructure()
        {

            // Define an array of customers.
            string[] strCustomerArray = new string[] { "Davis, Dan", "Jones, Jerry", "Smith, Sally" };
            short shoIndex = 0;
            string strCustomerList = "";

            // Add customers to the customer list until shoIndex is less than or
            // equal to 0.
            do
            {
                strCustomerList = strCustomerList + strCustomerArray[shoIndex] + "; ";
                shoIndex++;
            } while (shoIndex <= 0);
            // strCustomerList = "Davis, Dan; "

        }

        protected void ForStructure()
        {

            // Define an array of suppliers.
            string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            string strSupplierList = "";

            // Add suppliers to the supplier list while i is less than or equal
            // to 4.
            for (short i = 0; i <= 4; i++)
            {
                strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
            }
            // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

        }

        protected void ForEachStructure()
        {

            // Define an array of suppliers.
            string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            string strSupplierList = "";

            // Add suppliers to the supplier list while suppliers remain in the
            // array.
            foreach (string strSupplier in strSupplierArray)
            {
                strSupplierList = strSupplierList + strSupplier + "; ";
            }
            // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

        }

        protected void BreakStatement()
        {

            // Define an array of suppliers.
            string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            string strSupplierList = "";

            // Add suppliers to the supplier list while i is less than or equal
            // to 4 or until 3 suppliers have been added to the supplier list.
            for (short i = 0; i <= 4; i++)
            {
                if (i <= 2)
                {
                    strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
                }
                else
                {
                    break;
                }
            }
            // strSupplierList = "Adidas; Babolat; Head; "

        }

        protected void ContinueStatement()
        {

            // Define an array of suppliers.
            string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            string strSupplierList = "";

            // Add every other supplier to the supplier list while i
            // is less than or equal to 4.
            for (short i = 0; i <= 4; i++)
            {
                if (i % 2 == 0)
                {
                    strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
                }
                else
                {
                    continue;
                }
            }
            // strSupplierList = "Adidas; Head; Prince; "

        }

    }
}