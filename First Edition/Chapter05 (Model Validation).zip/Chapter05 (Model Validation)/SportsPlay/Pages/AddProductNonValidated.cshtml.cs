﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class AddProductNonValidatedModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public int SupplierId { get; set; }
        public string Product { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public decimal Price { get; set; }
        public byte NumberInStock { get; set; }
        public byte NumberOnOrder { get; set; }
        public byte ReorderLevel { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            // Set the message.
            MessageColor = "Green";
            Message = Product + " was successfully added.";

        }

        public void OnPostCancel()
        {

            // Set the message.
            MessageColor = "Red";
            Message = "The operation was cancelled. No data was affected.";

        }

    }
}