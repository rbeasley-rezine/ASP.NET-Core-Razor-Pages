﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Validators;
using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class AddEmployeeValidatedModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int EmployeeId { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Please enter a last name.")]
        [StringLength(50)]
        public string LastName { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Please enter a first name.")]
        [StringLength(50)]
        public string FirstName { get; set; }

        [Display(Name = "Middle Initial")]
        [StringLength(1)]
        public string MiddleInitial { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Please enter an address.")]
        [StringLength(50)]
        public string Address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Please enter a city.")]
        [StringLength(50)]
        public string City { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Please select a state.")]
        public string State { get; set; }

        [Display(Name = "Zip Code")]
        [RegularExpression(@"\d{5}", ErrorMessage = "Please enter a zip code that contains exactly 5 numeric characters.")]
        [Required(ErrorMessage = "Please enter a zip code.")]
        [StringLength(5)]
        public string ZipCode { get; set; }

        [Display(Name = "Phone")]
        [RegularExpression(@"\(\d{3}\)\ \d{3}\-\d{4}", ErrorMessage = "Please enter a phone of the form: (999) 999-9999.")]
        [Required(ErrorMessage = "Please enter a phone.")]
        [StringLength(20)]
        public string Phone { get; set; }

        [Display(Name = "Email Address")]
        [EmailAddressDomain(EAD: "SportsPlay.com", ErrorMessage = "Please enter an email address domain of SportsPlay.com.")]
        [RegularExpression(@"\S+\@\S+\.\S+", ErrorMessage = "Please enter an email address of the form: aaa@bbb.ccc.")]
        [Required(ErrorMessage = "Please enter an email address.")]
        [StringLength(50)]
        public string EmailAddress { get; set; }

        [Display(Name = "Password")]
        [RegularExpression(@"\S{5,10}", ErrorMessage = "Please enter a password that contains between 5 and 10 non-blank characters.")]
        [Required(ErrorMessage = "Please enter a password.")]
        [StringLength(10)]
        public string Password { get; set; }

        [Display(Name = "Status")]
        [Required(ErrorMessage = "Please select a status.")]
        public string Status { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            if (ModelState.IsValid) // This condition is required to test the outcome of the email address domain validation code.
            {
                // Set the message.
                MessageColor = "Green";
                Message = FirstName + " " + MiddleInitial + " " + LastName + " was successfully added.";
            }
            else
            {
                // Set the message.
                MessageColor = "Red";
                Message = FirstName + " " + MiddleInitial + " " + LastName + " was NOT successfully added. Please enter an email address domain of SportsPlay.com.";
            }

        }

        public void OnPostCancel()
        {

            // Set the message.
            MessageColor = "Red";
            Message = "The operation was cancelled. No data was affected.";

        }

    }
}