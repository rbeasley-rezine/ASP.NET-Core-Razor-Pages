﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class AddProductValidatedModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int ProductId { get; set; }

        [Display(Name = "Category")]
        [Required(ErrorMessage = "Please select a category.")]
        public int CategoryId { get; set; }

        [Display(Name = "Supplier")]
        [Required(ErrorMessage = "Please select a supplier.")]
        public int SupplierId { get; set; }

        [Display(Name = "Product")]
        [Required(ErrorMessage = "Please enter a product.")]
        [StringLength(50)]
        public string Product { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "Please enter a description.")]
        public string Description { get; set; }

        [Display(Name = "Image")]
        [Required(ErrorMessage = "Please enter an image.")]
        [StringLength(50)]
        public string Image { get; set; }

        [Display(Name = "Price")]
        [Range(0.00, 10000.00, ErrorMessage = "Please enter a price between $0.00 and $10,000.00.")]
        [RegularExpression(@"\d{1,5}\.\d{2}", ErrorMessage = "Please enter a price of the form: 99999.99.")]
        [Required(ErrorMessage = "Please enter a price.")]
        public decimal Price { get; set; }

        [Display(Name = "Number in Stock")]
        [Range(0, 200, ErrorMessage = "Please enter a number in stock between 0 and 200.")]
        [RegularExpression(@"\d{1,3}", ErrorMessage = "Please enter a number in stock of the form: 999.")]
        [Required(ErrorMessage = "Please enter a number in stock.")]
        public byte NumberInStock { get; set; }

        [Display(Name = "Number on Order")]
        [Range(0, 200, ErrorMessage = "Please enter a number on order between 0 and 200.")]
        [RegularExpression(@"\d{1,3}", ErrorMessage = "Please enter a number on order of the form: 999.")]
        [Required(ErrorMessage = "Please enter a number on order.")]
        public byte NumberOnOrder { get; set; }

        [Display(Name = "Reorder Level")]
        [Range(0, 200, ErrorMessage = "Please enter a reorder level between 0 and 200.")]
        [RegularExpression(@"\d{1,3}", ErrorMessage = "Please enter a reorder level of the form: 999.")]
        [Required(ErrorMessage = "Please enter a reorder level.")]
        public byte ReorderLevel { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            // Set the message.
            MessageColor = "Green";
            Message = Product + " was successfully added.";

        }

        public void OnPostCancel()
        {

            // Set the message.
            MessageColor = "Red";
            Message = "The operation was cancelled. No data was affected.";

        }

    }
}