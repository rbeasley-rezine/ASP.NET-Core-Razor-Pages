﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages
{
    [BindProperties]
    public class AddEmployeeNonValidatedModel : PageModel
    {

        public string MessageColor;
        public string Message;

        public int EmployeeId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Phone { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public string Status { get; set; }

        public void OnGet()
        {
        }

        public void OnPostAdd()
        {

            // Set the message.
            MessageColor = "Green";
            Message = FirstName + " " + MiddleInitial + " " + LastName + " was successfully added.";

        }

        public void OnPostCancel()
        {

            // Set the message.
            MessageColor = "Red";
            Message = "The operation was cancelled. No data was affected.";

        }

    }
}