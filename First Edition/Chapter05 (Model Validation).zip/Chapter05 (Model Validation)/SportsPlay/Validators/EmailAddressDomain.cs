﻿using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Validators
{
    public class EmailAddressDomainAttribute : ValidationAttribute
    {

        private readonly string EmailAddressDomain;
        public EmailAddressDomainAttribute(string EAD)
        {
            EmailAddressDomain = EAD;
        }

        public override bool IsValid(object value)
        {

            if (value == null)
            {
                // Do not validate the email address domain.
                // This is necessary when implementing a cancel
                // button and no validation is to occur.
                return true;
            }
            else
            {
                // Validate the email address domain.
                string strEmailAddress = value.ToString();
                int intEmailAddressLength = strEmailAddress.Length;
                int intStartOfEmailAddressDomain = strEmailAddress.IndexOf("@") + 1;
                string strEmailAddressDomain = strEmailAddress.Substring(intStartOfEmailAddressDomain, intEmailAddressLength - intStartOfEmailAddressDomain);
                if (strEmailAddressDomain == EmailAddressDomain)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

    }
}