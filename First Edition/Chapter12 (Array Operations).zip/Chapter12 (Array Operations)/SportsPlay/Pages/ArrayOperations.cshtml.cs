﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class ArrayOperationsModel : PageModel
    {

        // One-Dimensional Arrays.

        // Declare a 3-element one-dimensional array of strings.
        string[] strShipperArray = new string[3];
        // strShipperArray[0] = null
        // strShipperArray[1] = null
        // strShipperArray[2] = null

        // Declare a 5-element one-dimensional array of strings.
        // Add items to the elements of the array upon initialization.
        string[] strCategoryArray = new string[5]
        {
            "Footwear - Men's", "Clothing - Men's", "Racquets",
            "Footwear - Women's", "Clothing - Women's"
        };
        // strCategoryArray[0] = "Footwear - Men's"
        // strCategoryArray[1] = "Clothing - Men's"
        // strCategoryArray[2] = "Racquets"
        // strCategoryArray[3] = "Footwear - Women's"
        // strCategoryArray[4] = "Clothing - Women's"

        // Two-Dimensional Arrays.

        // Declare a 3x2 6-element two-dimensional array of decimals.
        decimal[,] decCommissionRateArray = new decimal[3, 2];
        // decCommissionRateArray[0, 0] = 0
        // decCommissionRateArray[0, 1] = 0
        // decCommissionRateArray[1, 0] = 0
        // decCommissionRateArray[1, 1] = 0
        // decCommissionRateArray[2, 0] = 0
        // decCommissionRateArray[2, 1] = 0

        // Declare a 3x7 21-element two-dimensional array of decimals.
        // Add items to the elements of the array upon initialization.
        decimal[,] decEquipmentSalesArray = new decimal[3, 7]
        {
            { 0, 119.99m, 170.92m, 134.50m, 234.76m, 102.99m, 0 },
            { 145.78m, 200.12m, 409.11m, 102.99m, 189.99m, 209.34m, 379.99m },
            { 230.45m, 0, 0, 0, 0, 0, 172.65m },
        };
        // decEquipmentSalesArray[0, 0] = 0
        // decEquipmentSalesArray[0, 1] = 119.99
        // decEquipmentSalesArray[0, 2] = 170.92
        // ⁞
        // decEquipmentSalesArray[2, 4] = 0
        // decEquipmentSalesArray[2, 5] = 0
        // decEquipmentSalesArray[2, 6] = 172.65

        public void OnGet()
        {

            // One-Dimensional Arrays.
            GetNumberOfElements1D();
            PopulateElements1D();
            RetrieveElements1D();
            SortElements1D();
            SearchElements1D();
            CopyElements1D();
            ReverseElements1D();
            ClearElements1D();

            // Two-Dimensional Arrays.
            GetNumberOfElements2D();
            PopulateElements2D();
            RetrieveElements2D();
            SortElements2D(); // Not providing an example.
            SearchElements2D();
            CopyElements2D();
            ReverseElements2D(); // Not providing an example.
            ClearElements2D(); // Not providing an example.

        }

        protected void GetNumberOfElements1D()
        {

            // Get the number of elements in the array.
            int intLength = strCategoryArray.Length;
            // intLength = 5

        }

        protected void PopulateElements1D()
        {

            // Add values to the elements of the array.
            strCategoryArray[0] = "Footwear - Men's";
            strCategoryArray[1] = "Clothing - Men's";
            strCategoryArray[2] = "Racquets";
            strCategoryArray[3] = "Footwear - Women's";
            strCategoryArray[4] = "Clothing - Women's";
            // strCategoryArray[0] = "Footwear - Men's"
            // strCategoryArray[1] = "Clothing - Men's"
            // strCategoryArray[2] = "Racquets"
            // strCategoryArray[3] = "Footwear - Women's"
            // strCategoryArray[4] = "Clothing - Women's"

        }

        protected void RetrieveElements1D()
        {

            // Declare the variables.
            string strCategory = "";
            string strCategoryList = "";

            // Get the third element of the array.
            strCategory = strCategoryArray[2];
            // strCategory = "Racquets"

            // Get all the elements of the array and add them to the list.
            for (int i = 0; i < strCategoryArray.Length; i++)
            {
                strCategoryList = strCategoryList + strCategoryArray[i] + "; ";
            }
            // strCategoryList = "Footwear - Men's; Clothing - Men's; Racquets;
            // Footwear - Women's; Clothing - Women's; "

        }

        protected void SortElements1D()
        {

            // Sort the array.
            Array.Sort(strCategoryArray);
            // strCategoryArray[0] = "Clothing - Men's"
            // strCategoryArray[1] = "Clothing - Women's"
            // strCategoryArray[2] = "Footwear - Men's"
            // strCategoryArray[3] = "Footwear - Women's"
            // strCategoryArray[4] = "Racquets"

        }

        protected void SearchElements1D()
        {

            // Declare the variables.
            int intIndex = 0;
            bool booFound = false;

            // This is a sequential search.
            for (int i = 0; i < strCategoryArray.Length; i++)
            {
                if (strCategoryArray[i] == "Footwear - Women's")
                {
                    intIndex = i;
                    booFound = true;
                    break;
                }
            }
            // intIndex = 3, booFound = true

            // This is a binary search.
            intIndex = Array.BinarySearch(strCategoryArray, "Footwear - Women's");
            if (intIndex >= 0)
            {
                booFound = true;
            }
            // intIndex = 3, booFound = true

        }

        protected void CopyElements1D()
        {

            // Declare another 5-element one-dimensional array of strings.
            string[] strCategoryArrayCopy = new string[5];
            // Copy the elements from the original (previously sorted) array
            // to the element values of the new array beginning at element [0]
            // in both arrays for the length of the original array.
            Array.Copy(strCategoryArray, 0, strCategoryArrayCopy, 0, strCategoryArray.Length);
            // strCategoryArrayCopy[0] = "Clothing - Men's"
            // strCategoryArrayCopy[1] = "Clothing - Women's"
            // strCategoryArrayCopy[2] = "Footwear - Men's"
            // strCategoryArrayCopy[3] = "Footwear - Women's"
            // strCategoryArrayCopy[4] = "Racquets"

        }

        protected void ReverseElements1D()
        {

            // Reverse the original (previously sorted) array.
            Array.Reverse(strCategoryArray);
            // strCategoryArray[0] = "Racquets"
            // strCategoryArray[1] = "Footwear - Women's"
            // strCategoryArray[2] = "Footwear - Men's"
            // strCategoryArray[3] = "Clothing - Women's"
            // strCategoryArray[4] = "Clothing - Men's"

        }

        protected void ClearElements1D()
        {

            // Clear elements 1 through 3 of the original (previously sorted)
            // array.
            Array.Clear(strCategoryArray, 1, 3);
            // strCategoryArray[0] = "Racquets"
            // strCategoryArray[1] = null
            // strCategoryArray[2] = null
            // strCategoryArray[3] = null
            // strCategoryArray[4] = "Clothing - Men's"

        }

        protected void GetNumberOfElements2D()
        {

            // Get the total number of elements in the array.
            int intLength = decEquipmentSalesArray.Length;
            // intLength = 21

            // Get the number of rows in the array.
            int intLengthRows = decEquipmentSalesArray.GetLength(0);
            // intLengthRows = 3

            // Get the number of columns in the array.
            int intLengthColumns = decEquipmentSalesArray.GetLength(1);
            // intLengthColumns = 7

        }

        protected void PopulateElements2D()
        {

            // Add values to the elements of the array.
            decEquipmentSalesArray[0, 0] = 0;
            decEquipmentSalesArray[0, 1] = 119.99m;
            decEquipmentSalesArray[0, 2] = 170.92m;
            decEquipmentSalesArray[0, 3] = 134.50m;
            decEquipmentSalesArray[0, 4] = 234.76m;
            decEquipmentSalesArray[0, 5] = 102.99m;
            decEquipmentSalesArray[0, 6] = 0;
            decEquipmentSalesArray[1, 0] = 145.78m;
            decEquipmentSalesArray[1, 1] = 200.12m;
            decEquipmentSalesArray[1, 2] = 409.11m;
            decEquipmentSalesArray[1, 3] = 102.99m;
            decEquipmentSalesArray[1, 4] = 189.99m;
            decEquipmentSalesArray[1, 5] = 209.34m;
            decEquipmentSalesArray[1, 6] = 379.99m;
            decEquipmentSalesArray[2, 0] = 230.45m;
            decEquipmentSalesArray[2, 1] = 0;
            decEquipmentSalesArray[2, 2] = 0;
            decEquipmentSalesArray[2, 3] = 0;
            decEquipmentSalesArray[2, 4] = 0;
            decEquipmentSalesArray[2, 5] = 0;
            decEquipmentSalesArray[2, 6] = 172.65m;
            // decEquipmentSalesArray[0, 0] = 0
            // decEquipmentSalesArray[0, 1] = 119.99
            // decEquipmentSalesArray[0, 2] = 170.92
            // ⁞
            // decEquipmentSalesArray[2, 4] = 0
            // decEquipmentSalesArray[2, 5] = 0
            // decEquipmentSalesArray[2, 6] = 172.65

        }

        protected void RetrieveElements2D()
        {

            // Declare the variables.
            decimal decEquipmentSales = 0;
            decimal decEquipmentSalesTotal = 0;

            // Get the element of the array.
            decEquipmentSales = decEquipmentSalesArray[1, 3];
            // decEquipmentSales = 102.99

            // Get all the elements of the array and sum them.
            for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
            {
                for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
                {
                    decEquipmentSalesTotal = decEquipmentSalesTotal + decEquipmentSalesArray[i, j];
                }
            }
            // decEquipmentSalesTotal = 2803.58

        }

        protected void SortElements2D()
        {

            // Not providing an example.

        }

        protected void SearchElements2D()
        {

            // Declare the variables.
            int intIndexI = 0;
            int intIndexJ = 0;
            bool booFound = false;

            // This is a sequential search.
            for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
            {
                for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
                {
                    if (decEquipmentSalesArray[i, j] == 409.11m)
                    {
                        intIndexI = i;
                        intIndexJ = j;
                        booFound = true;
                        break;
                    }
                }
                if (booFound)
                {
                    break;
                }
            }
            // intIndexI = 1, intIndexJ = 2, booFound = true

        }

        protected void CopyElements2D()
        {

            // Declare another 3x7 21-element two-dimensional array of decimals.
            decimal[,] decEquipmentSalesArrayCopy = new decimal[3, 7];
            // Copy the elements from the original array to the element
            // values of the new array beginning at element [0] in both arrays
            // for the length of the original array.
            Array.Copy(decEquipmentSalesArray, 0, decEquipmentSalesArrayCopy, 0, decEquipmentSalesArray.Length);
            // decEquipmentSalesArrayCopy[0, 0] = 0
            // decEquipmentSalesArrayCopy[0, 1] = 119.99
            // decEquipmentSalesArrayCopy[0, 2] = 170.92
            // ⁞
            // decEquipmentSalesArrayCopy[2, 4] = 0
            // decEquipmentSalesArrayCopy[2, 5] = 0
            // decEquipmentSalesArrayCopy[2, 6] = 172.65

        }

        protected void ReverseElements2D()
        {

            // Not providing an example.

        }

        protected void ClearElements2D()
        {

            // Not providing an example.

        }

    }
}