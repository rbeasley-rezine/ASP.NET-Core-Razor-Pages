﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class ArithmeticOperationsModel : PageModel
    {

        public void OnGet()
        {

            BasicArithmeticOperations();
            OrderOfPrecedenceAndAssociativity();
            Parentheses();
            MathClassOperations();

        }

        protected void BasicArithmeticOperations()
        {

            // Declare the variables.
            short shoNumber1 = 0;
            double douNumber1 = 0;
            double douNumber2 = 0;
            double douResult;

            // Add the numbers.
            douNumber1 = 40;
            douNumber2 = 8;
            douResult = douNumber1 + douNumber2;
            // douResult = 48

            // Subtract the numbers.
            douNumber1 = 70;
            douNumber2 = 10;
            douResult = douNumber1 - douNumber2;
            // douResult = 60

            // Multiply the numbers.
            douNumber1 = 3;
            douNumber2 = 2;
            douResult = douNumber1 * douNumber2;
            // douResult = 6

            // Divide the numbers.
            douNumber1 = 7;
            douNumber2 = 4;
            douResult = douNumber1 / douNumber2;
            // douResult = 1.75

            // Divide the first number by the second number giving the remainder.
            douNumber1 = 12;
            douNumber2 = 7;
            douResult = douNumber1 % douNumber2;
            // douResult = 5

            // Increment the number after the assignment.
            shoNumber1 = 3;
            douResult = shoNumber1++;
            // douResult = 3, shoNumber1 = 4

            // Decrement the number after the assignment.
            shoNumber1 = 7;
            douResult = shoNumber1--;
            // douResult = 7, shoNumber1 = 6

            // Increment the number before the assignment.
            shoNumber1 = 12;
            douResult = ++shoNumber1;
            // douResult = 13, shoNumber1 = 13

            // Decrement the number before the assignment.
            shoNumber1 = 40;
            douResult = --shoNumber1;
            // douResult = 39, shoNumber1 = 39

        }

        protected void OrderOfPrecedenceAndAssociativity()
        {

            // Declare the variables.
            byte bytValue;
            double douNumber1 = 2;
            double douNumber2 = 3;
            double douNumber3 = 4;
            double douResult;

            // This is an example of order of precedence.
            bytValue = 1;
            douResult = douNumber1 * douNumber2 * ++bytValue;
            // douResult = 12

            // This is the equivalent.
            bytValue = 1;
            douResult = douNumber1 * douNumber2 * (++bytValue);
            // douResult = 12

            // This is an example of order of precedence.
            douResult = douNumber1 + douNumber2 * douNumber3;
            // douResult = 14

            // This is the equivalent.
            douResult = douNumber1 + (douNumber2 * douNumber3);
            // douResult = 14

            // This is an example of left associativity.
            douResult = douNumber1 * douNumber2 % douNumber3;
            // douResult = 2

            // This is the equivalent.
            douResult = (douNumber1 * douNumber2) % douNumber3;
            // douResult = 2

            // This is an example of right associativity.
            douResult = douNumber1 = douNumber2 = douNumber3;
            // douResult = 4

            // This is the equivalent.
            douResult = (douNumber1 = (douNumber2 = douNumber3));
            // douResult = 4

        }

        protected void Parentheses()
        {

            // Declare the variables.
            double douNumber1 = 2;
            double douNumber2 = 3;
            double douNumber3 = 4;
            double douResult;

            // This is an example of order of precedence.
            douResult = douNumber1 + douNumber2 * douNumber3;
            // douResult = 14

            // This is the equivalent.
            douResult = douNumber1 + (douNumber2 * douNumber3);
            // douResult = 14

            // This is overriding the order of precedence using parentheses.
            douResult = (douNumber1 + douNumber2) * douNumber3;
            // douResult = 20

            // This is an example of left associativity.
            douResult = douNumber1 * douNumber2 % douNumber3;
            // douResult = 2

            // This is the equivalent.
            douResult = (douNumber1 * douNumber2) % douNumber3;
            // douResult = 2

            // This is overriding the left associativity using parentheses.
            douResult = douNumber1 * (douNumber2 % douNumber3);
            // douResult = 6

        }

        protected void MathClassOperations()
        {

            // Declare the variables.
            double douNumber1 = 0;
            double douNumber2 = 0;
            double douResult;

            // Compute the absolute value.
            douNumber1 = -3.21;
            douResult = Math.Abs(douNumber1);
            // douResult = 3.21

            // Compute the ceiling.
            douNumber1 = 3.21;
            douResult = Math.Ceiling(douNumber1);
            // douResult = 4

            // Compute the ceiling.
            douNumber1 = -3.21;
            douResult = Math.Ceiling(douNumber1);
            // douResult = -3

            // Compute the ceiling.
            douNumber1 = 0.21;
            douResult = Math.Ceiling(douNumber1);
            // douResult = 1

            // Compute the ceiling.
            douNumber1 = -0.21;
            douResult = Math.Ceiling(douNumber1);
            // douResult = 0

            // Compute the floor.
            douNumber1 = 3.21;
            douResult = Math.Floor(douNumber1);
            // douResult = 3

            // Compute the floor.
            douNumber1 = -3.21;
            douResult = Math.Floor(douNumber1);
            // douResult = -4

            // Compute the floor.
            douNumber1 = 0.21;
            douResult = Math.Floor(douNumber1);
            // douResult = 0

            // Compute the floor.
            douNumber1 = -0.21;
            douResult = Math.Floor(douNumber1);
            // douResult = -1

            // Get the larger of the two numbers.
            douNumber1 = 3.5;
            douNumber2 = 7.5;
            douResult = Math.Max(douNumber1, douNumber2);
            // douResult = 7.5

            // Get the smaller of the two numbers.
            douNumber1 = 3.5;
            douNumber2 = 7.5;
            douResult = Math.Min(douNumber1, douNumber2);
            // douResult = 3.5

            // Raise the number to the 3rd power.
            douNumber1 = 3;
            douResult = Math.Pow(douNumber1, 3);
            // douResult = 27

            // Round the number up or down to the nearest even value.
            // This is banker's rounding, which is the default.
            douNumber1 = 1.5;
            douResult = Math.Round(douNumber1, 0, MidpointRounding.ToEven);
            // douResult = 2 (Rounded up.)

            // Round the number up or down to the nearest even value.
            // This is banker's rounding, which is the default.
            douNumber1 = 2.5;
            douResult = Math.Round(douNumber1, 0, MidpointRounding.ToEven);
            // douResult = 2 (Rounded down.)

            // Round the number up or down to the nearest value.
            // This is standard rounding, which is not the default.
            douNumber1 = 1.5;
            douResult = Math.Round(douNumber1, 0, MidpointRounding.AwayFromZero);
            // douResult = 2 (Rounded up.)

            // Round the number up or down to the nearest value.
            // This is standard rounding, which is not the default.
            douNumber1 = 2.5;
            douResult = Math.Round(douNumber1, 0, MidpointRounding.AwayFromZero);
            // douResult = 3 (Rounded up.)

            // Get the sign of the number.
            douNumber1 = 12;
            douResult = Math.Sign(douNumber1);
            // douResult = 1

            // Get the sign of the number.
            douNumber1 = -12;
            douResult = Math.Sign(douNumber1);
            // douResult = -1

            // Compute the square root of the number.
            douNumber1 = 16;
            douResult = Math.Sqrt(douNumber1);
            // douResult = 4

            // Truncate the number.
            douNumber1 = 3.712;
            douResult = Math.Truncate(douNumber1);
            // douResult = 3

        }

    }
}