﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace SportsPlay.Pages
{
    public class AssignmentOperationsModel : PageModel
    {

        public void OnGet()
        {

            // VariableDeclarations();
            // ConstantDeclarations();
            // AssignmentOperations();
            // Enumeration();
            ExceptionHandling();

        }

        protected void VariableDeclarations()
        {

            // Declare Booleans.
            bool booPreferredCustomer = true;
            bool booOrderShipped = false;

            // Declare characters.
            char[] chaZipCode = new char[] { '4', '6', '1', '3', '1' };
            char[] chaPrice = new char[] { '$', '1', '9', '9', '.', '0', '0' };

            // Declare strings.
            string strSupplier = "";
            string strProduct = "Babolat Pure Aero French Open";

            // Declare numbers.
            byte bytNumber = 10;
            decimal decNumber = -10.00m;
            double douNumber = -10.00;
            float floNumber = -10.12345f;
            int intNumber = -10;
            long lonNumber = -10;
            sbyte sbyNumber = -10;
            short shoNumber = -10;
            ushort ushNumber = 10;
            uint uinNumber = 10;
            ulong uloNumber = 10;

        }

        protected void ConstantDeclarations()
        {

            // Declare constants.
            const byte bytDaysInJanuary = 31;
            const decimal decSalesTaxRate = 0.07m;
            const string strLastNameLabel = "Last Name";

        }

        protected void AssignmentOperations()
        {

            // Declare the variables.
            double douNumber1 = 0;
            double douNumber2 = 0;

            // This is a simple numeric assignment statement.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 = douNumber2;
            // douNumber1 = 7

            // This is a compound numeric assignment statement that is
            // equivalent to douNumber1 = douNumber1 + douNumber2.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 += douNumber2;
            // douNumber1 = 10

            // This is a compound numeric assignment statement that is
            // equivalent to douNumber1 = douNumber1 - douNumber2.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 -= douNumber2;
            // douNumber1 = -4

            // This is a compound numeric assignment statement that is
            // equivalent to douNumber1 = douNumber1 * douNumber2.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 *= douNumber2;
            // douNumber1 = 21

            // This is a compound numeric assignment statement that is
            // equivalent to douNumber1 = douNumber1 / douNumber2.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 /= douNumber2;
            // douNumber1 = 0.42857142857142855

            // This is a compound numeric assignment statement that is
            // equivalent to douNumber1 = douNumber1 % douNumber2.
            douNumber1 = 3;
            douNumber2 = 7;
            douNumber1 %= douNumber2;
            // douNumber1 = 3

        }

        enum DiscountRate : byte
        {

            Standard = 10,
            Select = 20,
            Preferred = 30

        }

        protected void Enumeration()
        {

            byte bytCustomerDiscountRate = (byte)DiscountRate.Preferred;
            // bytCustomerDiscountRate = 30

        }

        protected void ExceptionHandling()
        {

            DivideNumberByZero();
            CatchDivideByZeroException();
            CatchFormatException();
            CatchIndexOutOfRangeException();
            CatchOverflowException();
            CatchMultipleExceptions();
        }

        protected void DivideNumberByZero()
        {

            // This is used to trigger the Exception Handler.
            // Divide the numerator by the denominator.
            decimal decNumerator = 3;
            decimal decDenominator = 0;
            decimal decResult = decNumerator / decDenominator;

        }

        protected void CatchDivideByZeroException()
        {

            // Check for a divide by zero exception.
            string strMessage = "";
            decimal decNumerator = 3;
            decimal decDenominator = 0;
            decimal decResult = 0;
            try
            {
                decResult = decNumerator / decDenominator;
                strMessage = "The division was successful.";
            }
            catch (DivideByZeroException objException)
            {
                strMessage = "The division was NOT successful. " + objException.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The division was NOT successful. Attempted to
            // divide by zero. Thank you."

        }

        protected void CatchFormatException()
        {

            // Check for a format exception.
            string strMessage = "";
            string strNumber = "abc";
            byte bytNumber = 0;
            try
            {
                bytNumber = Convert.ToByte(strNumber);
                strMessage = "The conversion was successful.";
            }
            catch (FormatException objException)
            {
                strMessage = "The conversion was NOT successful. " + objException.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The conversion was NOT successful. Input string was
            // not in a correct format. Thank you."

        }

        protected void CatchIndexOutOfRangeException()
        {

            // Check for an index out of range exception.
            string strMessage = "";
            string[] strNameArray = new string[] { "Bill", "Mary", "Steve" };
            string strName = "";
            try
            {
                strName = strNameArray[5];
                strMessage = "The lookup was successful.";
            }
            catch (IndexOutOfRangeException objException)
            {
                strMessage = "The lookup was NOT successful. " + objException.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The lookup was NOT successful. Index was outside the
            // bounds of the array. Thank you."

        }

        protected void CatchOverflowException()
        {

            // Check for an overflow exception.
            string strMessage = "";
            int intNumber = 256;
            byte bytNumber = 0;
            try
            {
                bytNumber = Convert.ToByte(intNumber);
                strMessage = "The assignment was successful.";
            }
            catch (OverflowException objException)
            {
                strMessage = "The assignment was NOT successful. " + objException.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The assignment was NOT successful. Value was either
            // too large or too small for an unsigned byte. Thank you."

        }

        protected void CatchMultipleExceptions()
        {

            // Check for multiple possible exceptions.
            string strMessage = "";
            string strNumber = "256";
            byte bytNumber = 0; 
            try
            {
                bytNumber = Convert.ToByte(strNumber);
                strMessage = "The conversion and assignment were successful.";
            }
            catch (FormatException objException)
            {
                strMessage = "The conversion was NOT successful. " + objException.Message;
            }
            catch (OverflowException objException)
            {
                strMessage = "The assignment was NOT successful. " + objException.Message;
            }
            catch (Exception objException)
            {
                strMessage = "Something else was NOT successful. " + objException.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The assignment was NOT successful. Value was either
            // too large or too small for an unsigned byte. Thank you."

        }

    }
}