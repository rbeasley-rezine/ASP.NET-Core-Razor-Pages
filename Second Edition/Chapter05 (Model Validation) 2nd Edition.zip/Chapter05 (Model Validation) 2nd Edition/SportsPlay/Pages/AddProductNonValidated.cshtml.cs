﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class AddProductNonValidatedModel : PageModel
{

    public string MessageColor;
    public string Message;

    public int ProductID { get; set; }
    public int CategoryID { get; set; }
    public int SupplierID { get; set; }
    public string Product { get; set; }
    public string Description { get; set; }
    public string Image { get; set; }
    public decimal Price { get; set; }
    public byte NumberInStock { get; set; }
    public byte NumberOnOrder { get; set; }
    public byte ReorderLevel { get; set; }

    public void OnGet()
    {
    }

    public void OnPostAdd()
    {

        // Set the message.
        MessageColor = "Green";
        Message = Product + " was successfully added.";

    }

}