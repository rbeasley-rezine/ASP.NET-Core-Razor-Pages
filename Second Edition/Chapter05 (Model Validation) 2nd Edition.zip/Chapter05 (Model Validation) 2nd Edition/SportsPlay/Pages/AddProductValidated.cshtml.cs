﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Validators;
using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Pages;

[BindProperties]
public class AddProductValidatedModel : PageModel
{

    public string MessageColor;
    public string Message;

    public int ProductID { get; set; }

    [Display(Name = "Category")]
    [Required(ErrorMessage = "Please select a category.")]
    public int CategoryID { get; set; }

    [Display(Name = "Supplier")]
    [Required(ErrorMessage = "Please select a supplier.")]
    public int SupplierID { get; set; }

    [Display(Name = "Product")]
    [ProductNumberPresent(ErrorMessage = "Please include a product name that begins with P#.")]
    [Required(ErrorMessage = "Please enter a product.")]
    [StringLength(50)]
    public string Product { get; set; }

    [Display(Name = "Description")]
    [Required(ErrorMessage = "Please enter a description.")]
    public string Description { get; set; }

    [Display(Name = "Image")]
    [Required(ErrorMessage = "Please enter an image.")]
    [RegularExpression(@"\S{1,}\.(jpg|png)", ErrorMessage = "Please enter an image that ends in .jpg or .png.")]
    [StringLength(50)]
    public string Image { get; set; }

    [Display(Name = "Price")]
    [Range(0.00, 10000.00, ErrorMessage = "Please enter a price between 0.00 and 10000.00.")]
    [Required(ErrorMessage = "Please enter a price.")]
    public decimal Price { get; set; }

    [Display(Name = "Number in Stock")]
    [Range(0, 200, ErrorMessage = "Please enter a number in stock between 0 and 200.")]
    [Required(ErrorMessage = "Please enter a number in stock.")]
    public byte NumberInStock { get; set; }

    [Display(Name = "Number on Order")]
    [Range(0, 200, ErrorMessage = "Please enter a number on order between 0 and 200.")]
    [Required(ErrorMessage = "Please enter a number on order.")]
    public byte NumberOnOrder { get; set; }

    [Display(Name = "Reorder Level")]
    [Range(0, 200, ErrorMessage = "Please enter a reorder level between 0 and 200.")]
    [Required(ErrorMessage = "Please enter a reorder level.")]
    public byte ReorderLevel { get; set; }

    public void OnGet()
    {
    }

    public void OnPostAdd()
    {

        if (ModelState.IsValid)
        {
            // Set the message.
            MessageColor = "Green";
            Message = Product + " was successfully added.";
        }

    }

}