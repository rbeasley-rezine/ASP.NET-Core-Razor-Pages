﻿using System.ComponentModel.DataAnnotations;

namespace SportsPlay.Validators;

public class ProductNumberPresentAttribute : ValidationAttribute
{

    public override bool IsValid(object objProduct)
    {

        if (objProduct == null)
        {
            // Do not validate the product name.
            return true;
        }
        else
        {
            // Make sure the product name begins with P#.
            string strProduct = objProduct.ToString();
            int intIndexOfPartNumber = strProduct.IndexOf("P#");
            if (intIndexOfPartNumber == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }

}