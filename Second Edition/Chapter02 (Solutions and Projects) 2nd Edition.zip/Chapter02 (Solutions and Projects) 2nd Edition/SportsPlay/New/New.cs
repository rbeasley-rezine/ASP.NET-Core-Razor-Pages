﻿namespace SportsPlay.New;

public class New
{
}
