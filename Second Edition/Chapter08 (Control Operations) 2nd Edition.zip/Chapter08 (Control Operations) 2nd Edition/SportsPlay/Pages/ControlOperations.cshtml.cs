﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ControlOperationsModel : PageModel
{

    public void OnGet()
    {

        PerformIf();
        PerformIfElse();
        PerformIfElseIf();
        PerformNestedIf();
        PerformSwitch();
        PerformSwitchThrough();
        PerformWhile();
        PerformDoWhile();
        PerformFor();
        PerformForEach();
        PerformBreak();
        PerformContinue();

    }

    protected void PerformIf()
    {

        PerformIfRelational();
        PerformIfEquality();
        PerformIfAnd();
        PerformIfOr();

    }

    protected void PerformIfRelational()
    {

        // Declare the variables.
        byte bytCustomerAge = 55;
        const decimal decDiscountRateSenior = 0.10m;
        decimal decSubtotal = 100.00m;

        // If the customer is 55 or older, apply the senior discount.
        if (bytCustomerAge >= 55)
        {
            decSubtotal = decSubtotal * (1 - decDiscountRateSenior);
        }
        // decSubtotal = 90.0000

    }

    protected void PerformIfEquality()
    {

        // Declare the variables.
        int intProductId = 5;
        string strMessage = "";

        // If the Product ID is 2, put out a message.
        if (intProductId == 2)
        {
            strMessage = "Sorry. That product is currently on backorder.";
        }
        // strMessage = ""

    }

    protected void PerformIfAnd()
    {

        // Declare the variables.
        byte bytNumberInStock = 4;
        byte bytReorderLevel = 5;
        byte bytNumberOnOrder = 0;
        bool booReorderProduct = false;

        // If the number in stock is less than or equal to the reorder
        // level, and if there is nothing already on order, then set
        // the number on order to the reorder level and indicate that
        // the product should be reordered.
        if (bytNumberInStock <= bytReorderLevel && bytNumberOnOrder == 0)
        {
            bytNumberOnOrder = bytReorderLevel;
            booReorderProduct = true;
        }
        // bytNumberOnOrder = 5, booReorderProduct = true

    }

    protected void PerformIfOr()
    {

        // Declare the variables.
        string strZipCode = "46131";
        bool booDeliveryAvailable = false;

        // If the zip code is 46131 or 46132, indicate that delivery
        // is available.
        if (strZipCode == "46131" || strZipCode == "46132")
        {
            booDeliveryAvailable = true;
        }
        // booDeliveryAvailable = true

    }

    protected void PerformIfElse()
    {

        // Declare the variables.
        string strState = "IN";
        const decimal decSalesTaxRate = 0.7m;
        decimal decSubtotal = 100.00m;
        decimal decTotal = 0;

        // Only apply sales tax if the customer resides in Indiana.
        if (strState == "IN")
        {
            decTotal = decSubtotal + (decSalesTaxRate * 10);
        }
        else
        {
            decTotal = decSubtotal;
        }
        // decTotal = 107.00

    }

    protected void PerformIfElseIf()
    {

        // Declare the variables.
        string strCustomerType = "Select";
        const decimal decDiscountRateStandard = 0.10m;
        const decimal decDiscountRateSelect = 0.20m;
        decimal decSubtotal = 100;

        // Apply the discount rate based on the type of customer.
        if (strCustomerType == "Standard")
        {
            decSubtotal = decSubtotal * (1 - decDiscountRateStandard);
        }
        else if (strCustomerType == "Select")
        {
            decSubtotal = decSubtotal * (1 - decDiscountRateSelect);
        }
        // decSubtotal = 80.00

    }

    protected void PerformNestedIf()
    {

        // Declare the variables.
        byte bytCustomerAge = 60;
        string strCustomerType = "Select";
        const decimal decDiscountRateSenior = 0.10m;
        const decimal decDiscountRateStandard = 0.10m;
        const decimal decDiscountRateSelect = 0.20m;
        decimal decSubtotal = 100;

        // If the customer is 55 or older, apply the senior discount.
        if (bytCustomerAge >= 55)
        {
            // Apply the discount rate based on the type of customer.
            if (strCustomerType == "Standard")
            {
                decSubtotal = decSubtotal * (1 - (decDiscountRateStandard + decDiscountRateSenior));
            }
            else if (strCustomerType == "Select")
            {
                decSubtotal = decSubtotal * (1 - (decDiscountRateSelect + decDiscountRateSenior));
            }
        }
        // decSubtotal = 70.00

    }

    protected void PerformSwitch()
    {

        // Declare the variables.
        string strCustomerType = "Select";
        const decimal decDiscountRateStandard = 0.10m;
        const decimal decDiscountRateSelect = 0.20m;
        decimal decSubtotal = 100;

        // Apply the discount rate based on the type of customer.
        switch (strCustomerType)
        {
            case "Standard":
                decSubtotal = decSubtotal * (1 - decDiscountRateStandard);
                break;
            case "Select":
                decSubtotal = decSubtotal * (1 - decDiscountRateSelect);
                break;
            default:
                // Do not apply a discount.
                break;
        }
        // decSubtotal = 80.00

    }

    protected void PerformSwitchThrough()
    {

        // Declare the variables.
        byte bytNumberOfOrderLines = 5;
        decimal decSubtotal = 100;
        decimal decDiscountRate = 0;

        // If the customer purchases 1-2 items, do not apply a discount.
        // If the customer purchases 3-4 items, apply a 10% discount.
        // If the customer purchases 5-6 items, apply a 20% discount.
        // If the customer purchases 7 or more items, apply a 30% discount.
        switch (bytNumberOfOrderLines)
        {
            case 1:
            case 2:
                break;
            case 3:
            case 4:
                decDiscountRate = 0.10m;
                break;
            case 5:
            case 6:
                decDiscountRate = 0.20m;
                break;
            default:
                decDiscountRate = 0.30m;
                break;
        }
        decSubtotal = decSubtotal * (1 - decDiscountRate);
        // decSubtotal = 80.00, decDiscountRate = 0.20

    }

    protected void PerformWhile()
    {

        // Define an array of customers.
        string[] strCustomerArray = new string[] { "Davis, Dan", "Jones, Jerry", "Smith, Sally" };
        short shoIndex = 0;
        string strCustomerList = "";

        // Add customers to the customer list while shoIndex is less than or
        // equal to 2.
        while (shoIndex <= 2)
        {
            strCustomerList = strCustomerList + strCustomerArray[shoIndex] + "; ";
            shoIndex++;
        }
        // strCustomerList = "Davis, Dan; Jones, Jerry; Smith, Sally; "

    }

    protected void PerformDoWhile()
    {

        // Define an array of customers.
        string[] strCustomerArray = new string[] { "Davis, Dan", "Jones, Jerry", "Smith, Sally" };
        short shoIndex = 0;
        string strCustomerList = "";

        // Add customers to the customer list until shoIndex is less than or
        // equal to 0.
        do
        {
            strCustomerList = strCustomerList + strCustomerArray[shoIndex] + "; ";
            shoIndex++;
        } while (shoIndex <= 0);
        // strCustomerList = "Davis, Dan; "

    }

    protected void PerformFor()
    {

        // Define an array of suppliers.
        string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
        string strSupplierList = "";

        // Add suppliers to the supplier list while i is less than or
        // equal to 4.
        for (short i = 0; i <= 4; i++)
        {
            strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
        }
        // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

    }

    protected void PerformForEach()
    {

        // Define an array of suppliers.
        string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
        string strSupplierList = "";

        // Add suppliers to the supplier list while suppliers remain
        // in the array.
        foreach (string strSupplier in strSupplierArray)
        {
            strSupplierList = strSupplierList + strSupplier + "; ";
        }
        // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

    }

    protected void PerformBreak()
    {

        // Define an array of suppliers.
        string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
        string strSupplierList = "";

        // Add suppliers to the supplier list while i is less than or equal
        // to 4 or until 3 suppliers have been added to the supplier list.
        for (short i = 0; i <= 4; i++)
        {
            if (i <= 2)
            {
                strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
            }
            else
            {
                break;
            }
        }
        // strSupplierList = "Adidas; Babolat; Head; "

    }

    protected void PerformContinue()
    {

        // Define an array of suppliers.
        string[] strSupplierArray = new string[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
        string strSupplierList = "";

        // Add every other supplier to the supplier list
        // while i is less than or equal to 4.
        for (short i = 0; i <= 4; i++)
        {
            if (i % 2 == 0)
            {
                strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
            }
            else
            {
                continue;
            }
        }
        // strSupplierList = "Adidas; Head; Prince; "

    }

}