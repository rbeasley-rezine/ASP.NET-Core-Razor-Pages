﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class CookiesWelcomeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public void OnGet()
    {

        // Get the cookies.
        int intEmployeeID = Convert.ToInt32(Request.Cookies["intEmployeeID"]);
        string strUser = Request.Cookies["strUser"];
        // Set the message.
        MessageColor = "Green";
        Message = "You have logged in successfully as " + strUser + "! Your Employee ID is " + intEmployeeID + ". Welcome to SportsPlay!";

    }

}