﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class SessionVariablesWelcomeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public void OnGet()
    {

        // Get the session variables.
        int intEmployeeID = Convert.ToInt32(HttpContext.Session.GetString("intEmployeeID"));
        string strUser = HttpContext.Session.GetString("strUser");
        // Set the message.
        MessageColor = "Green";
        Message = "You have logged in successfully as " + strUser + "! Your Employee ID is " + intEmployeeID + ". Welcome to SportsPlay!";

    }

}