﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class TempDataVariablesWelcomeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public void OnGet()
    {

        // Get the temp data variables.
        int intEmployeeID = Convert.ToInt32(TempData["intEmployeeID"]);
        string strUser = TempData["strUser"].ToString();
        // Set the message.
        MessageColor = "Green";
        Message = "You have logged in successfully as " + strUser + "! Your Employee ID is " + intEmployeeID + ". Welcome to SportsPlay!";

    }

}