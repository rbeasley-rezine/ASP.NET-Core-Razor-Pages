﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class RouteDataParametersWelcomeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public void OnGet(int intEmployeeID, string strUser)
    {

        // Set the message.
        MessageColor = "Green";
        Message = "You have logged in successfully as " + strUser + "! Your Employee ID is " + intEmployeeID + ". Welcome to SportsPlay!";

    }

}