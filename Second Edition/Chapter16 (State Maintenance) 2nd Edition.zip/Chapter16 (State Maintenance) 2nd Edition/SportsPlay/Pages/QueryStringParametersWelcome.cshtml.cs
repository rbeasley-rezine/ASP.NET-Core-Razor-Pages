﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class QueryStringParametersWelcomeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public void OnGet()
    {

        // Get the query string parameters.
        int intEmployeeID = Convert.ToInt32(Request.Query["intEmployeeID"]);
        string strUser = Request.Query["strUser"];
        // Set the message.
        MessageColor = "Green";
        Message = "You have logged in successfully as " + strUser + "! Your Employee ID is " + intEmployeeID + ". Welcome to SportsPlay!";

    }

}