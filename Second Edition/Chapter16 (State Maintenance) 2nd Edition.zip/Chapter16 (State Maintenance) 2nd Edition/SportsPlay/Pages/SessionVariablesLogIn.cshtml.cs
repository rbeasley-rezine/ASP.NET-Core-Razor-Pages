﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class SessionVariablesLogInModel : PageModel
{

    public string MessageColor;
    public string Message;

    public string EmailAddress { get; set; }
    public string Password { get; set; }

    public void OnGet()
    {
    }

    public RedirectResult OnPostLogin()
    {

        // Check the user's credentials.
        if (EmailAddress == "rregal@sportsplay.com" && Password == "abc")
        {
            // Set the variables to be passed to the Welcome page.
            int intEmployeeID = 2;
            string strUser = "Richard R Regal (Manager)";
            // Set the session variables.
            HttpContext.Session.SetString("intEmployeeID", intEmployeeID.ToString());
            HttpContext.Session.SetString("strUser", strUser);
            // Go to the Welcome page.
            return Redirect("SessionVariablesWelcome");
        }
        else
        {
            // Set the message.
            MessageColor = "Red";
            Message = "You have entered an invalid email address and password combination. Please try again.";
            return null;
        }

    }

}