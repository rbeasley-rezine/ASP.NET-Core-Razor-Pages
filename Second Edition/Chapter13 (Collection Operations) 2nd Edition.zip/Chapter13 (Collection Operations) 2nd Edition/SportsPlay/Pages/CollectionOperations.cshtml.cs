﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class CollectionOperationsModel : PageModel
{

    public void OnGet()
    {

        UseStack();
        UseQueue();
        UseLinkedList();
        UseSortedList();
        UseList();

    }

    protected void UseStack()
    {

        // Declare the stack.
        Stack<string> strProductStack = new Stack<string>();

        // Declare the outputs.
        int intCount = 0;
        string strProduct = "";
        string strProductList = "";

        // Add items to the stack.
        strProductStack.Push("Nike Men's Summer Flex Ace 7 Inch Short");
        strProductStack.Push("Nike Men's Summer RF Premier Jacket");
        strProductStack.Push("Nike Zoom Vapor 9.5 Tour");
        // strProductStack[0] = "Nike Zoom Vapor 9.5 Tour" (Top)
        // strProductStack[1] = "Nike Men's Summer RF Premier Jacket"
        // strProductStack[2] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

        // Get the number of items in the stack.
        intCount = strProductStack.Count;
        // intCount = 3

        // Get the next item on the stack but don't remove it from the stack.
        strProduct = strProductStack.Peek();
        // strProduct = "Nike Zoom Vapor 9.5 Tour"
        // strProductStack[0] = "Nike Zoom Vapor 9.5 Tour" (Top)
        // strProductStack[1] = "Nike Men's Summer RF Premier Jacket"
        // strProductStack[2] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

        // Get all the items of the stack and add them to the list.
        foreach (string strProductItem in strProductStack)
        {
            strProductList = strProductList + strProductItem + "; ";
        }
        // strProductList = "Nike Zoom Vapor 9.5 Tour; Nike Men's Summer
        // RF Premier Jacket; Nike Men's Summer Flex Ace 7 Inch Short; "

        // Get the next item on the stack and remove it from the stack.
        strProduct = strProductStack.Pop();
        // strProduct = "Nike Zoom Vapor 9.5 Tour"
        // strProductStack[0] = "Nike Men's Summer RF Premier Jacket" (Top)
        // strProductStack[1] = "Nike Men's Summer Flex Ace 7 Inch Short" (Bottom)

        // Clear the stack.
        strProductStack.Clear();
        // strProductStack = empty

    }

    protected void UseQueue()
    {

        // Declare the queue.
        Queue<string> strProductQueue = new Queue<string>();

        // Declare the outputs.
        int intCount = 0;
        string strProduct = "";
        string strProductList = "";

        // Add items to the queue.
        strProductQueue.Enqueue("Nike Men's Summer Flex Ace 7 Inch Short");
        strProductQueue.Enqueue("Nike Men's Summer RF Premier Jacket");
        strProductQueue.Enqueue("Nike Zoom Vapor 9.5 Tour");
        // strProductQueue[0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beginning)
        // strProductQueue[1] = "Nike Men's Summer RF Premier Jacket"
        // strProductQueue[2] = "Nike Zoom Vapor 9.5 Tour" (End)

        // Get the number of items in the queue.
        intCount = strProductQueue.Count;
        // intCount = 3

        // Get the next item in the queue but don't remove it from the queue.
        strProduct = strProductQueue.Peek();
        // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
        // strProductQueue[0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beginning)
        // strProductQueue[1] = "Nike Men's Summer RF Premier Jacket"
        // strProductQueue[2] = "Nike Zoom Vapor 9.5 Tour" (End)

        // Get all the items of the queue and add them to the list.
        foreach (string strProductItem in strProductQueue)
        {
            strProductList = strProductList + strProductItem + "; ";
        }
        // strProductList = "Nike Men's Summer Flex Ace 7 Inch Short;
        // Nike Men's Summer RF Premier Jacket; Nike Zoom Vapor 9.5 Tour; "

        // Get the next item in the queue and remove it from the queue.
        strProduct = strProductQueue.Dequeue();
        // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
        // strProductQueue[0] = "Nike Men's Summer RF Premier Jacket" (Beginning)
        // strProductQueue[1] = "Nike Zoom Vapor 9.5 Tour" (End)

        // Clear the queue.
        strProductQueue.Clear();
        // strProductQueue = empty

    }

    protected void UseLinkedList()
    {

        // Declare the linked list.
        LinkedList<string> strSupplierLinkedList = new LinkedList<string>();

        // Declare a linked list node.
        LinkedListNode<string> llnCurrent;

        // Declare the outputs.
        int intCount = 0;
        bool booFound = false;
        string strSupplierList = "";

        // Add a node to the start of the linked list.
        strSupplierLinkedList.AddFirst("Adidas");
        // strSupplierLinkedList[0] = "Adidas" (Start and End)

        // Add a node to the end of the linked list.
        strSupplierLinkedList.AddLast("Prince");
        // strSupplierLinkedList[0] = "Adidas" (Start)
        // strSupplierLinkedList[1] = "Prince" (End)

        // Add a node after the specified node in the linked list.
        llnCurrent = strSupplierLinkedList.Find("Adidas");
        strSupplierLinkedList.AddAfter(llnCurrent, "Babolat");
        // strSupplierLinkedList[0] = "Adidas" (Start)
        // strSupplierLinkedList[1] = "Babolat"
        // strSupplierLinkedList[2] = "Prince" (End)

        // Add a node before the specified node in the linked list.
        llnCurrent = strSupplierLinkedList.Find("Prince");
        strSupplierLinkedList.AddBefore(llnCurrent, "Head");
        // strSupplierLinkedList[0] = "Adidas" (Start)
        // strSupplierLinkedList[1] = "Babolat"
        // strSupplierLinkedList[2] = "Head"
        // strSupplierLinkedList[3] = "Prince" (End)

        // Get the number of nodes in the linked list.
        intCount = strSupplierLinkedList.Count;
        // intCount = 4

        // Determine whether or not the specified value exists in the linked list.
        booFound = strSupplierLinkedList.Contains("Babolat");
        // booFound = true

        // Get all the items of the linked list and add them to the list.
        foreach (string strSupplierItem in strSupplierLinkedList)
        {
            strSupplierList = strSupplierList + strSupplierItem + "; ";
        }
        // strSupplierList = "Adidas; Babolat; Head; Prince; "

        // Remove the specified node from the linked list.
        strSupplierLinkedList.Remove("Babolat");
        // strSupplierLinkedList[0] = "Adidas" (Start)
        // strSupplierLinkedList[1] = "Head"
        // strSupplierLinkedList[2] = "Prince" (End)

        // Clear the linked list.
        strSupplierLinkedList.Clear();
        // strSupplierLinkedList = empty

    }

    protected void UseSortedList()
    {

        // Declare the sorted list.
        SortedList<string, string> strShipperSortedList = new SortedList<string, string>();

        // Declare the outputs.
        int intCount = 0;
        string strShipper = "";
        bool booFound = false;
        string strShipperList = "";

        // Add key-value pairs to the sorted list.
        strShipperSortedList.Add("FedEx", "Federal Express");
        strShipperSortedList.Add("UPS", "United Parcel Service");
        strShipperSortedList.Add("USPS", "Un St Po Se");
        // strShipperSortedList[0] = {[FedEx, Federal Express]} (Start)
        // strShipperSortedList[1] = {[UPS, United Parcel Service]}
        // strShipperSortedList[2] = {[USPS, Un St Po Se]} (End)

        // Update the value associated with the specified key in the sorted list.
        strShipperSortedList["USPS"] = "United States Postal Service";
        // strShipperSortedList[0] = {[FedEx, Federal Express]} (Start)
        // strShipperSortedList[1] = {[UPS, United Parcel Service]}
        // strShipperSortedList[2] = {[USPS, United States Postal Service]} (End)

        // Get the number of elements in the sorted list.
        intCount = strShipperSortedList.Count;
        // intCount = 3

        // Get the value associated with the specified key in the sorted list.
        strShipper = strShipperSortedList["FedEx"];
        // strShipper = "Federal Express"

        // Determine whether or not the sorted list contains the specified key.
        booFound = strShipperSortedList.ContainsKey("UPS");
        // booFound = true

        // Determine whether or not the sorted list contains the specified value.
        booFound = strShipperSortedList.ContainsValue("United Parcel Service");
        // booFound = true

        // Get all the items of the sorted list and add them to the list.
        foreach (string strShipperItem in strShipperSortedList.Values)
        {
            strShipperList = strShipperList + strShipperItem + "; ";
        }
        // strShipperList = "Federal Express; United Parcel Service;
        // United States Postal Service; "

        // Remove the element with the specified key from the sorted list.
        strShipperSortedList.Remove("UPS");
        // strShipperSortedList[0] = {[FedEx, Federal Express]} (Start)
        // strShipperSortedList[1] = {[USPS, United States Postal Service]} (End)

        // Clear the sorted list.
        strShipperSortedList.Clear();
        // strShipperSortedList = empty

    }

    private class Supplier
    {
        public string? Supplier1;
        public string? PointOfContact;
        public string? EmailAddress;
    }

    protected void UseList()
    {

        // Declare the list.
        List<Supplier> objSupplierList = new List<Supplier>();

        // Declare the outputs.
        int intCount = 0;
        Supplier objSupplier;
        string strPointOfContact = "";
        bool booFound = false;
        string strSupplierList = "";

        // Add objects to the list.
        objSupplier = new Supplier { Supplier1 = "Adidas", PointOfContact = "Alan Alte", EmailAddress = "aalte@adidas.com" };
        objSupplierList.Add(objSupplier);
        objSupplier = new Supplier { Supplier1 = "Prince", PointOfContact = "Phil Pelkin", EmailAddress = "ppelkin@prince.com" };
        objSupplierList.Add(objSupplier);
        // objSupplierList[0] = {"Adidas", "Alan Alte", "aalte@adidas.com"} (Start)
        // objSupplierList[1] = {"Prince", "Phil Pelkin", "ppelkin@prince.com"} (End)

        // Insert an object into the list at the specified index.
        objSupplier = new Supplier { Supplier1 = "Babolat", PointOfContact = "Bill Baker", EmailAddress = "bbaker@babolat.com" };
        objSupplierList.Insert(1, objSupplier);
        // objSupplierList[0] = {"Adidas", "Alan Alte", "aalte@adidas.com"} (Start)
        // objSupplierList[1] = {"Babolat", "Bill Baker", "bbaker@babolat.com"}
        // objSupplierList[2] = {"Prince", "Phil Pelkin", "ppelkin@prince.com"} (End)

        // Add an object after the specified object in the list.
        int intIndex = objSupplierList.FindIndex(s => s.Supplier1.Contains("Babolat"));
        objSupplier = new Supplier { Supplier1 = "Head", PointOfContact = "Hailey Hawkins", EmailAddress = "hhawkins@head.com" };
        objSupplierList.Insert(intIndex + 1, objSupplier);
        // objSupplierList[0] = {"Adidas", "Alan Alte", "aalte@adidas.com"} (Start)
        // objSupplierList[1] = {"Babolat", "Bill Baker", "bbaker@babolat.com"}
        // objSupplierList[2] = {"Head", "Hailey Hawkins", "hhawkins@head.com"}
        // objSupplierList[3] = {"Prince", "Phil Pelkin", "ppelkin@prince.com"} (End)

        // Get the number of objects in the list.
        intCount = objSupplierList.Count;
        // intCount = 4

        // Get the specified object in the list.
        objSupplier = objSupplierList.Find(s => s.Supplier1 == "Babolat");
        // objSupplier = {"Babolat", "Bill Baker", "bbaker@babolat.com"}

        // Get the value of the specified property of the specified object in the list.
        strPointOfContact = objSupplier.PointOfContact;
        // strPointOfContact = "Bill Baker"

        // Determine whether or not the specified object exists in the list.
        booFound = objSupplierList.Exists(s => s.Supplier1 == "Babolat");
        // booFound = true

        // Get all the items of the list and add them to the list.
        foreach (Supplier objSupplierItem in objSupplierList)
        {
            strSupplierList = strSupplierList + objSupplierItem.Supplier1 + "; ";
        }
        // strSupplierList = "Adidas; Babolat; Head; Prince; "

        // Remove the specified object from the list.
        objSupplierList.RemoveAll(s => s.Supplier1 == "Babolat");
        // objSupplierList[0] = {"Adidas", "Alan Alte", "aalte@adidas.com"} (Start)
        // objSupplierList[1] = {"Head", "Hailey Hawkins", "hhawkins@head.com"}
        // objSupplierList[2] = {"Prince", "Phil Pelkin", "ppelkin@prince.com"} (End)

        // Clear the list.
        objSupplierList.Clear();
        // objSupplierList = empty

    }

}