﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ArrayOperationsModel : PageModel
{

    // Declare a 5-element one-dimensional array of strings.
    // Add items to the elements of the array upon initialization.
    string[] strCategoryArray = new string[5]
    {
        "Footwear - Men's", "Clothing - Men's", "Racquets",
        "Footwear - Women's", "Clothing - Women's"
    };
    // strCategoryArray[0] = "Footwear - Men's"
    // strCategoryArray[1] = "Clothing - Men's"
    // strCategoryArray[2] = "Racquets"
    // strCategoryArray[3] = "Footwear - Women's"
    // strCategoryArray[4] = "Clothing - Women's"

    // Declare a 2x3 6-element two-dimensional array of decimals.
    // Add items to the elements of the array upon initialization.
    decimal[,] decEquipmentSalesArray = new decimal[2, 3]
    {
        { 0.00m, 119.99m, 170.92m },
        { 145.78m, 200.12m, 409.11m }
    };
    // decEquipmentSalesArray[0, 0] = 0.00
    // decEquipmentSalesArray[0, 1] = 119.99
    // decEquipmentSalesArray[0, 2] = 170.92
    // decEquipmentSalesArray[1, 0] = 145.78
    // decEquipmentSalesArray[1, 1] = 200.12
    // decEquipmentSalesArray[1, 2] = 409.11

    public void OnGet()
    {

        // One-Dimensional Arrays.
        GetNumberOfElements1D();
        PopulateElements1D();
        RetrieveElements1D();
        SortElements1D();
        SearchElementsSequential1D();
        SearchElementsBinary1D();
        CopyElements1D();
        ReverseElements1D();
        ClearElements1D();

        // Two-Dimensional Arrays.
        GetNumberOfElements2D();
        PopulateElements2D();
        RetrieveElements2D();
        SortElements2D();
        SearchElementsSequential2D();
        SearchElementsBinary2D(); // A binary search of a two-dimensional array is not possible, so no example is provided.
        CopyElements2D();
        ReverseElements2D();
        ClearElements2D();

    }

    protected void GetNumberOfElements1D()
    {

        // Get the number of elements in the array.
        int intLength = strCategoryArray.Length;
        // intLength = 5

    }

    protected void PopulateElements1D()
    {

        // Add values to the elements of the array.
        strCategoryArray[0] = "Footwear - Men's";
        strCategoryArray[1] = "Clothing - Men's";
        strCategoryArray[2] = "Racquets";
        strCategoryArray[3] = "Footwear - Women's";
        strCategoryArray[4] = "Clothing - Women's";
        // strCategoryArray[0] = "Footwear - Men's"
        // strCategoryArray[1] = "Clothing - Men's"
        // strCategoryArray[2] = "Racquets"
        // strCategoryArray[3] = "Footwear - Women's"
        // strCategoryArray[4] = "Clothing - Women's"

    }

    protected void RetrieveElements1D()
    {

        // Declare the variables.
        string strCategory = "";
        string strCategoryList = "";

        // Get the third element of the array.
        strCategory = strCategoryArray[2];
        // strCategory = "Racquets"

        // Get all the elements of the array and add them to the list.
        for (int i = 0; i < strCategoryArray.Length; i++)
        {
            strCategoryList = strCategoryList + strCategoryArray[i] + "; ";
        }
        // strCategoryList = "Footwear - Men's; Clothing - Men's;
        // Racquets; Footwear - Women's; Clothing - Women's; "

    }

    protected void SortElements1D()
    {

        // Sort the array.
        Array.Sort(strCategoryArray);
        // strCategoryArray[0] = "Clothing - Men's"
        // strCategoryArray[1] = "Clothing - Women's"
        // strCategoryArray[2] = "Footwear - Men's"
        // strCategoryArray[3] = "Footwear - Women's"
        // strCategoryArray[4] = "Racquets"

    }

    protected void SearchElementsSequential1D()
    {

        // Declare the variables.
        int intIndex = 0;
        bool booFound = false;

        // Search the sorted array for "Footwear - Women's".
        for (int i = 0; i < strCategoryArray.Length; i++)
        {
            if (strCategoryArray[i] == "Footwear - Women's")
            {
                intIndex = i;
                booFound = true;
                break;
            }
        }
        // intIndex = 3, booFound = true

    }

    protected void SearchElementsBinary1D()
    {

        // Declare the variables.
        int intIndex = 0;
        bool booFound = false;

        // Search the sorted array for "Footwear - Women's".
        intIndex = Array.BinarySearch(strCategoryArray, "Footwear - Women's");
        if (intIndex >= 0)
        {
            booFound = true;
        }
        // intIndex = 3, booFound = true

    }

    protected void CopyElements1D()
    {

        // Declare another 5-element one-dimensional array of strings.
        string[] strCategoryArrayCopy = new string[5];
        // Copy the elements from the original (sorted) array to the
        // elements of the new array beginning at element [0] in both
        // arrays for the length of the original (sorted) array.
        Array.Copy(strCategoryArray, 0, strCategoryArrayCopy, 0, strCategoryArray.Length);
        // strCategoryArrayCopy[0] = "Clothing - Men's"
        // strCategoryArrayCopy[1] = "Clothing - Women's"
        // strCategoryArrayCopy[2] = "Footwear - Men's"
        // strCategoryArrayCopy[3] = "Footwear - Women's"
        // strCategoryArrayCopy[4] = "Racquets"

    }

    protected void ReverseElements1D()
    {

        // Reverse the sorted array.
        Array.Reverse(strCategoryArray);
        // strCategoryArray[0] = "Racquets"
        // strCategoryArray[1] = "Footwear - Women's"
        // strCategoryArray[2] = "Footwear - Men's"
        // strCategoryArray[3] = "Clothing - Women's"
        // strCategoryArray[4] = "Clothing - Men's"

    }

    protected void ClearElements1D()
    {

        // Clear the elements of the reversed array.
        Array.Clear(strCategoryArray);
        // strCategoryArray[0] = null
        // strCategoryArray[1] = null
        // strCategoryArray[2] = null
        // strCategoryArray[3] = null
        // strCategoryArray[4] = null

    }

    protected void GetNumberOfElements2D()
    {

        // Get the total number of elements in the array.
        int intLength = decEquipmentSalesArray.Length;
        // intLength = 6

        // Get the number of rows in the array.
        int intLengthRows = decEquipmentSalesArray.GetLength(0);
        // intLengthRows = 2

        // Get the number of columns in the array.
        int intLengthColumns = decEquipmentSalesArray.GetLength(1);
        // intLengthColumns = 3

    }

    protected void PopulateElements2D()
    {

        // Add values to the elements of the array.
        decEquipmentSalesArray[0, 0] = 0;
        decEquipmentSalesArray[0, 1] = 119.99m;
        decEquipmentSalesArray[0, 2] = 170.92m;
        decEquipmentSalesArray[1, 0] = 145.78m;
        decEquipmentSalesArray[1, 1] = 200.12m;
        decEquipmentSalesArray[1, 2] = 409.11m;
        // decEquipmentSalesArray[0, 0] = 0.00
        // decEquipmentSalesArray[0, 1] = 119.99
        // decEquipmentSalesArray[0, 2] = 170.92
        // decEquipmentSalesArray[1, 0] = 145.78
        // decEquipmentSalesArray[1, 1] = 200.12
        // decEquipmentSalesArray[1, 2] = 409.11

    }

    protected void RetrieveElements2D()
    {

        // Declare the variables.
        decimal decEquipmentSales = 0;
        decimal decEquipmentSalesTotal = 0;

        // Get the element in the first row second column of the array.
        decEquipmentSales = decEquipmentSalesArray[0, 1];
        // decEquipmentSales = 119.99

        // Sum up all the elements of the array.
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                decEquipmentSalesTotal = decEquipmentSalesTotal + decEquipmentSalesArray[i, j];
            }
        }
        // decEquipmentSalesTotal = 1045.92

    }

    protected void SortElements2D()
    {

        // Declare a 6-element one-dimensional array of decimals.
        decimal[] decEquipmentSalesArray1D = new decimal[decEquipmentSalesArray.Length];

        // Put the elements in the two-dimensional array into the
        // one-dimensional array.
        int intIndex = 0;
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                decEquipmentSalesArray1D[intIndex] = decEquipmentSalesArray[i, j];
                intIndex++;
            }
        }

        // Sort the one-dimensional array.
        Array.Sort(decEquipmentSalesArray1D);

        // Put the elements in the sorted one-dimensional array into
        // the two-dimensional array.
        intIndex = 0;
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                decEquipmentSalesArray[i, j] = decEquipmentSalesArray1D[intIndex];
                intIndex++;
            }
        }
        // decEquipmentSalesArray[0, 0] = 0.00
        // decEquipmentSalesArray[0, 1] = 119.99
        // decEquipmentSalesArray[0, 2] = 145.78
        // decEquipmentSalesArray[1, 0] = 170.92
        // decEquipmentSalesArray[1, 1] = 200.12
        // decEquipmentSalesArray[1, 2] = 409.11

    }

    protected void SearchElementsSequential2D()
    {

        // Declare the variables.
        int intIndexI = 0;
        int intIndexJ = 0;
        bool booFound = false;

        // Search the sorted array for 145.78".
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                if (decEquipmentSalesArray[i, j] == 145.78m)
                {
                    intIndexI = i;
                    intIndexJ = j;
                    booFound = true;
                    break;
                }
            }
            if (booFound)
            {
                break;
            }
        }
        // intIndexI = 1, intIndexJ = 2, booFound = true

    }

    protected void SearchElementsBinary2D()
    {

        // A binary search of a two-dimensional array is not possible,
        // so no example is provided.

    }

    protected void CopyElements2D()
    {

        // Declare another 2x3 6-element two-dimensional array of decimals.
        decimal[,] decEquipmentSalesArrayCopy = new decimal[2, 3];
        // Copy the elements from the original (sorted) array to the
        // elements of the new array beginning at element [0] in both
        // arrays for the length of the original (sorted) array.
        Array.Copy(decEquipmentSalesArray, 0, decEquipmentSalesArrayCopy, 0, decEquipmentSalesArray.Length);
        // decEquipmentSalesArrayCopy[0, 0] = 0.00
        // decEquipmentSalesArrayCopy[0, 1] = 119.99
        // decEquipmentSalesArrayCopy[0, 2] = 145.78
        // decEquipmentSalesArrayCopy[1, 0] = 170.92
        // decEquipmentSalesArrayCopy[1, 1] = 200.12
        // decEquipmentSalesArrayCopy[1, 2] = 409.11

    }

    protected void ReverseElements2D()
    {

        // Declare a 6-element one-dimensional array of decimals.
        decimal[] decEquipmentSalesArray1D = new decimal[decEquipmentSalesArray.Length];

        // Put the elements in the sorted two-dimensional array into
        // the one-dimensional array.
        int intIndex = 0;
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                decEquipmentSalesArray1D[intIndex] = decEquipmentSalesArray[i, j];
                intIndex++;
            }
        }

        // Reverse the one-dimensional array.
        Array.Reverse(decEquipmentSalesArray1D);

        // Put the elements in the reversed one-dimensional array into
        // the two-dimensional array.
        intIndex = 0;
        for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
        {
            for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
            {
                decEquipmentSalesArray[i, j] = decEquipmentSalesArray1D[intIndex];
                intIndex++;
            }
        }
        // decEquipmentSalesArray[0, 0] = 409.11
        // decEquipmentSalesArray[0, 1] = 200.12
        // decEquipmentSalesArray[0, 2] = 170.92
        // decEquipmentSalesArray[1, 0] = 145.78
        // decEquipmentSalesArray[1, 1] = 119.99
        // decEquipmentSalesArray[1, 2] = 0.00

    }

    protected void ClearElements2D()
    {

        // Clear the elements of the reversed array.
        Array.Clear(decEquipmentSalesArray);
        // decEquipmentSalesArray[0, 0] = 0
        // decEquipmentSalesArray[0, 1] = 0
        // decEquipmentSalesArray[0, 2] = 0
        // decEquipmentSalesArray[1, 0] = 0
        // decEquipmentSalesArray[1, 1] = 0
        // decEquipmentSalesArray[1, 2] = 0

    }

}