﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class PageProcessingModel : PageModel
{

    public string MessageColor;
    public string Message;

    public string EmailAddress { get; set; }
    public string Password { get; set; }

    public void OnGet()
    {
    }

    public void OnPostLogIn()
    {

        // Log in the user.
        if (EmailAddress == "rregal@sportsplay.com" && Password == "abc")
        {
            // Set the message.
            MessageColor = "Green";
            Message = "You have logged in successfully! Welcome to SportsPlay!";
        }
        else
        {
            // Set the message.
            MessageColor = "Red";
            Message = "You have entered an invalid email address and password combination. Please try again.";
        }

    }

}