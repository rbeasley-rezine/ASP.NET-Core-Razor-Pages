﻿namespace SportsPlay.Classes;

public static class Credentials
{

    public static string GenerateEmailAddress(string strFirstName, string strLastName)
    {

        // Generate an email address. The person’s email address is
        // composed of his or her first initial and last name followed
        // by @sportsplay.com.
        string strFirstInitial = strFirstName.Substring(0, 1).ToLower();
        strLastName = strLastName.ToLower();
        string strEmailAddress = strFirstInitial + strLastName + "@sportsplay.com";
        return strEmailAddress;

    }

    public static string GeneratePassword(string strFirstName, string strLastName)
    {

        // Generate a password. The person’s password is composed
        // of his or her first and last initials followed by five
        // randomly generated characters.
        string strFirstInitial = strFirstName.Substring(0, 1).ToLower();
        string strLastInitial = strLastName.Substring(0, 1).ToLower();
        string strPassword = strFirstInitial + strLastInitial;
        Random objRandom = new Random();
        for (int i = 1; i <= 5; i++)
        {
            int intRandomNumber = objRandom.Next(1, 5);
            switch (intRandomNumber)
            {
                case 1:
                    strPassword = strPassword + "!";
                    break;
                case 2:
                    strPassword = strPassword + "#";
                    break;
                case 3:
                    strPassword = strPassword + "$";
                    break;
                case 4:
                    strPassword = strPassword + "%";
                    break;
                case 5:
                    strPassword = strPassword + "*";
                    break;
            }
        }
        return strPassword;

    }

}
