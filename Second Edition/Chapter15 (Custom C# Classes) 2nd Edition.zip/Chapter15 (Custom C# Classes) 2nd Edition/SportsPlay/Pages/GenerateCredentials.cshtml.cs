﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using SportsPlay.Classes;

namespace SportsPlay.Pages;

public class GenerateCredentialsModel : PageModel
{

    public void OnGet()
    {

        // Initialize the first name and last name.
        string strFirstName = "Dawn";
        string strLastName = "Okon";

        // Generate an email address.
        string strEmailAddress = Credentials.GenerateEmailAddress(strFirstName, strLastName);
        // strEmailAddress = "dokon@sportsplay.com"

        // Generate a password.
        string strPassword = Credentials.GeneratePassword(strFirstName, strLastName);
        // strPassword = "do!#$%$"

    }

}