﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class FileSystemOperationsModel : PageModel
{

    private readonly IWebHostEnvironment IWebHostEnvironment;
    public FileSystemOperationsModel(IWebHostEnvironment IWHE)
    {
        IWebHostEnvironment = IWHE;
    }

    public void OnGet()
    {

        // CreateFile();
        // WriteToFile();
        // ReadFromFile();
        // CopyFile();
        // DeleteFile();
        // GetPropertiesOfFile();
        // GetAttributesOfFile();
        // SetPropertiesOfFile();
        // SetAttributesOfFile();

    }

    protected void CreateFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Create the file if it doesn't already exist.
        string strMessage = "";
        if (System.IO.File.Exists(strFilePath))
        {
            strMessage = "That file already exists.";
        }
        else
        {
            System.IO.File.Create(strFilePath);
            strMessage = "File successfully created.";
        }
        // strMessage = "File successfully created."

    }

    protected void WriteToFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Write to the file.
        string strContract = "AGREEMENT BETWEEN SportsPlay AND Adidas" + Environment.NewLine + Environment.NewLine + "This Deed of Agreement is made and entered into on the 4th day of July 20xx.";
        System.IO.File.AppendAllText(strFilePath, strContract);

    }

    protected void ReadFromFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Read from the file.
        string strContract = System.IO.File.ReadAllText(strFilePath);
        // strContract =
        // AGREEMENT BETWEEN SportsPlay AND Adidas
        // 
        // This Deed of Agreement is made and entered into on the 4th day
        // of July 20xx.

    }

    protected void CopyFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Set the path of the file to be copied.
        string strFilePathCopy = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas_Copy.txt";

        // Make a copy of the file.
        System.IO.File.Copy(strFilePath, strFilePathCopy);

    }

    protected void DeleteFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas_Copy.txt";

        // Delete the file.
        System.IO.File.Delete(strFilePath);

    }

    protected void GetPropertiesOfFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Get the date and time properties of the file.
        DateTime datCreated = System.IO.File.GetCreationTime(strFilePath);
        DateTime datModified = System.IO.File.GetLastWriteTime(strFilePath);
        DateTime datAccessed = System.IO.File.GetLastAccessTime(strFilePath);
        // datCreated = {6/6/2023 12:35:26 PM}
        // datModified = {6/6/2023 12:45:29 PM}
        // datAccessed = {6/7/2023 10:14:05 AM}

    }

    protected void GetAttributesOfFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Get the read-only and hidden attributes of the file.
        FileAttributes fiaFileAttributes = System.IO.File.GetAttributes(strFilePath);
        bool booReadOnly = (fiaFileAttributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly;
        bool booHidden = (fiaFileAttributes & FileAttributes.Hidden) == FileAttributes.Hidden;
        // booReadOnly = false
        // booHidden = false

    }

    protected void SetPropertiesOfFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Set the date and time properties of the file.
        System.IO.File.SetCreationTime(strFilePath, DateTime.Now);
        System.IO.File.SetLastWriteTime(strFilePath, DateTime.Now);
        System.IO.File.SetLastAccessTime(strFilePath, DateTime.Now);

    }

    protected void SetAttributesOfFile()
    {

        // Set the path of the file.
        string strFilePath = IWebHostEnvironment.WebRootPath + "\\contracts\\" + "Contract_Adidas.txt";

        // Set the file attributes to read-only and hidden.
        System.IO.File.SetAttributes(strFilePath, FileAttributes.ReadOnly | FileAttributes.Hidden);

    }

}