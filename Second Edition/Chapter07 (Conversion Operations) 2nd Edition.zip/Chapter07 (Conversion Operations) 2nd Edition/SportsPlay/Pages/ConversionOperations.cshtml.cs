﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ConversionOperationsModel : PageModel
{

    public void OnGet()
    {

        PerformWideningConversions();
        PerformNarrowingConversions();
        PerformConvertClassConversions();

    }

    protected void PerformWideningConversions()
    {

        // Implicitly convert an 8-bit unsigned integer to
        // a 16-bit unsigned integer.
        byte bytNumber = 100;
        ushort ushNumber = 0;
        ushNumber = bytNumber;
        // ushNumber = 100

        // Implicitly convert a 32-bit signed integer to
        // a 64-bit signed integer.
        int intNumber = -123;
        long lonNumber = 0;
        lonNumber = intNumber;
        // lonNumber = -123

        // Implicitly convert an 8-bit signed integer to
        // a 32-bit signed single-precision floating-point number.
        sbyte sbyNumber = -12;
        float floNumber = 0f;
        floNumber = sbyNumber;
        // floNumber = -12

        // Implicitly convert a 32-bit signed single-precision
        // floating-point number to a 64-bit signed double-precision
        // floating-point number.
        float floNumberSmaller = 12345.6789f;
        double douNumberLarger = 0;
        douNumberLarger = floNumberSmaller;
        // douNumberLarger = 12345.6787109375

        // Implicitly convert the variable types in the
        // expression before evaluating the expression.
        double douNumber1 = 3;
        short shoNumber2 = 7;
        short shoNumber3 = 12;
        double douAverage = 0;
        douAverage = (douNumber1 + shoNumber2 + shoNumber3) / 3;
        // douAverage = 7.33...

    }

    protected void PerformNarrowingConversions()
    {

        // Explicitly convert (i.e., cast) a 16-bit unsigned
        // integer to an 8-bit unsigned integer.
        ushort ushNumber = 100;
        byte bytNumber = 0;
        bytNumber = (byte)ushNumber;
        // bytNumber = 100

        // Explicitly convert (i.e., cast) a 64-bit signed integer
        // to a 32-bit signed integer.
        long lonNumber = -123;
        int intNumber = 0;
        intNumber = (int)lonNumber;
        // intNumber = -123

        // Explicitly convert (i.e., cast) a 128-bit signed
        // decimal number to a 64-bit signed double-precision
        // floating-point number.
        decimal decNumber = 123.45m;
        double douNumber = 0;
        douNumber = (double)decNumber;
        // douNumber = 123.45

        // Explicitly convert (i.e., cast) a 32-bit signed
        // single-precision floating-point number to an 8-bit
        // signed integer.
        float floNumber = -12.50f;
        sbyte sbyNumber = 0;
        sbyNumber = (sbyte)floNumber;
        // sbyNumber = -12

        // Explicitly convert (i.e., cast) a 16-bit signed
        // integer to an 8-bit unsigned integer.
        short shoNumberSigned = -100;
        byte bytNumberUnsigned = 0;
        bytNumberUnsigned = (byte)shoNumberSigned;
        // bytNumberUnsigned = 156

        // Explicitly convert (i.e., cast) a 16-bit unsigned integer
        // to an 8-bit unsigned integer that is too large to fit.
        ushort ushNumberTooLarge = 65535;
        byte bytNumberTooSmall = 0;
        bytNumberTooSmall = (byte)ushNumberTooLarge;
        // bytNumberTooSmall = 255

    }

    protected void PerformConvertClassConversions()
    {

        // Convert an 8-bit unsigned integer to its equivalent
        // 16-bit Unicode character.
        byte bytNumber = 65;
        char[] chaUnicodeCharacter = new char[1];
        chaUnicodeCharacter[0] = Convert.ToChar(bytNumber);
        // chaUnicodeCharacter[0] = "A"

        // Convert a DateTime structure to its equivalent
        // immutable, fixed-length Unicode string.
        DateTime datDateTime = DateTime.Today;
        string strDateTime = "";
        strDateTime = Convert.ToString(datDateTime);
        // strDateTime = "5/29/2023 12:00:00 AM"

        // Convert an 8-bit signed integer to its equivalent
        // 16-bit unsigned integer.
        sbyte sbyReorderLevel = 33;
        ushort ushReorderLevel = 0;
        ushReorderLevel = Convert.ToUInt16(sbyReorderLevel);
        // ushReorderLevel = 33

        // Convert a 32-bit signed single-precision floating-point
        // number to its equivalent 64-bit signed double-precision
        // floating-point number.
        float floAmount = 7.1234f;
        double douAmount = 0;
        douAmount = Convert.ToDouble(floAmount);
        // douAmount = 7.1234002113342285

        // Convert a 32-bit signed integer to its equivalent
        // Boolean value (true or false).
        int intFlag = 1;
        bool booFlag = false;
        booFlag = Convert.ToBoolean(intFlag);
        // booFlag = true

        // Convert an immutable, fixed-length Unicode string to
        // its equivalent 8-bit unsigned integer.
        string strAge = "3";
        byte bytAge = 0;
        bytAge = Convert.ToByte(strAge);
        // bytAge = 3

        // Convert an immutable, fixed-length Unicode string to
        // its equivalent DateTime structure.
        string strDateTimeToday = "5/29/2023";
        DateTime datDateTimeToday = new DateTime();
        datDateTimeToday = Convert.ToDateTime(strDateTimeToday);
        // datDateTimeToday = {5/29/2023 12:00:00 AM}

        // Convert a 16-bit unsigned integer to its equivalent
        // 8-bit signed integer.
        ushort ushNumberOnOrder = 100;
        sbyte sbyNumberOnOrder = 0;
        sbyNumberOnOrder = Convert.ToSByte(ushNumberOnOrder);
        // sbyNumberOnOrder = 100

        // Convert a 64-bit signed double-precision floating-point
        // number to its equivalent 32-bit signed single-precision
        // floating-point number.
        double douRefund = -123.45;
        float floRefund = 0;
        floRefund = Convert.ToSingle(douRefund);
        // floRefund = -123.45

        // Convert a 128-bit signed decimal number to its
        // equivalent 16-bit signed integer.
        decimal decNumberInStock = 122.5m;
        short shoNumberInStock = 0;
        shoNumberInStock = Convert.ToInt16(decNumberInStock);
        // shoNumberInStock = 122

    }

}