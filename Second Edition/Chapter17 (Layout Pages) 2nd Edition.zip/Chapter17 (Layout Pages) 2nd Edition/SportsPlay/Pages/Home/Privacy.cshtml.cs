﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages.Home;

public class PrivacyModel : PageModel
{

    public void OnGet()
    {

        // Set the header data.
        ViewData["Page"] = "Privacy";
        ViewData["User"] = HttpContext.Session.GetString("strUser");
        ViewData["UserStatus"] = HttpContext.Session.GetString("strUserStatus");
        ViewData["MessageColor"] = "Green";
        ViewData["Message"] = "Please read the privacy statement below.";

    }

}
