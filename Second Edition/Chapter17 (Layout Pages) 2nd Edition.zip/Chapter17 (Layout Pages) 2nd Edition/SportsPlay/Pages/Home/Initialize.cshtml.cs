﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages.Home;

public class InitializeModel : PageModel
{

    public RedirectResult OnGet()
    {

        // Log out the user.
        HttpContext.Session.Clear();

        // Initialize the header data.
        HttpContext.Session.SetString("strUser", "*");
        HttpContext.Session.SetString("strUserStatus", "*");
        return Redirect("Home/LogIn");

    }

}
