﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class DateAndTimeOperationsModel : PageModel
{

    public void OnGet()
    {

        UseDateRelatedProperties();
        UseDateRelatedMethods();
        PerformDateFormatting();
        PerformDateParsing();
        UseTimeRelatedProperties();
        UseTimeRelatedMethods();
        PerformTimeFormatting();

    }

    protected void UseDateRelatedProperties()
    {

        // Get the date for display. The time part of the date defaults
        // to 12:00:00 AM because we are only retrieving the date.
        string strToday = DateTime.Today.ToString();
        // strToday = "3/21/2023 12:00:00 AM"

        // Declare a new DateTime structure to hold the date.
        DateTime datToday = new DateTime();
        // datToday = {1/1/0001 12:00:00 AM}

        // Assign the date to the DateTime structure.
        datToday = DateTime.Today;
        // datToday = {3/21/2023 12:00:00 AM}

        // Hardcode the current date.
        DateTime datCurrent = new DateTime(2023, 03, 21, 00, 00, 00);
        // datCurrent = {3/21/2023 12:00:00 AM}

        // Get the year.
        int intYear = datCurrent.Year;
        // intYear = 2023

        // Get the month.
        int intMonth = datCurrent.Month;
        // intMonth = 3

        // Get the day.
        int intDay = datCurrent.Day;
        // intDay = 21

        // Get the day of the year.
        int intDayOfYear = datCurrent.DayOfYear;
        // intDayOfYear = 80

        // Get the day of the week.
        string strDayOfWeek = datCurrent.DayOfWeek.ToString();
        // strDayOfWeek = "Tuesday"

    }

    protected void UseDateRelatedMethods()
    {

        // Hardcode the current date.
        DateTime datCurrent = new DateTime(2023, 03, 21, 00, 00, 00);
        // datCurrent = {3/21/2023 12:00:00 AM}

        // Declare a new DateTime structure to hold the new date.
        DateTime datNew = new DateTime();
        // datNew = {1/1/0001 12:00:00 AM}

        // Add 1 year to the current date giving the new date.
        datNew = datCurrent.AddYears(1);
        // datNew = {3/21/2024 12:00:00 AM}

        // Add 3 months to the current date giving the new date.
        datNew = datCurrent.AddMonths(3);
        // datNew = {6/21/2023 12:00:00 AM}

        // Add 5 days to the current date giving the new date.
        datNew = datCurrent.AddDays(5);
        // datNew = {3/26/2023 12:00:00 AM}

        // Check to see if daylight saving time is in effect.
        bool booIsDaylightSavingTime = datCurrent.IsDaylightSavingTime();
        // booIsDaylightSavingTime = true

        // Check to see if this is a leap year.
        bool booIsLeapYear = DateTime.IsLeapYear(datCurrent.Year);
        // booIsLeapYear = false

        // Compare the first date to the second date.
        // If result < 0, first date < second date.
        // If result = 0, first date = second date.
        // If result > 0, first date > second date.
        DateTime datFirst = new DateTime(2023, 03, 21, 00, 00, 00);
        DateTime datSecond = new DateTime(2023, 03, 20, 00, 00, 00);
        int intResult = datFirst.CompareTo(datSecond);
        // intResult = 1

        // Determine how many days have elapsed since the
        // first-of-year date.
        DateTime datFirstOfYear = new DateTime(2023, 01, 01, 00, 00, 00);
        TimeSpan timTimeSpan = datCurrent.Subtract(datFirstOfYear);
        int intDaysElapsed = timTimeSpan.Days;
        // intDaysElapsed = 79

    }

    protected void PerformDateFormatting()
    {

        // Hardcode the current date.
        DateTime datCurrent = new DateTime(2023, 03, 21, 00, 00, 00);
        // datCurrent = {3/21/2023 12:00:00 AM}

        // Declare a date string.
        string strDate = "";
        // strDate = ""

        // Format the current date as a long date.
        strDate = datCurrent.ToLongDateString();
        // strDate = "Tuesday, March 21, 2023"

        // Format the current date as a short date.
        strDate = datCurrent.ToShortDateString();
        // strDate = "3/21/2023"

        // Customize the current date using format specifiers.
        strDate = datCurrent.ToString("dddd, MMMM dd, yyyy g");
        // strDate = "Tuesday, March 21, 2023 AD"

    }

    protected void PerformDateParsing()
    {

        // Declare the required DateTime structure and variables.
        DateTime datParsed = new DateTime();
        string strDate = "";
        bool booParseSuccessful = false;

        // Attempt to parse a valid date (with dashes) from a string.
        // Check to make sure the parse was successful.
        strDate = "02-28-2023";
        booParseSuccessful = DateTime.TryParse(strDate, out datParsed);
        // datParsed = {2/28/2023 12:00:00 AM}, booParseSuccessful = true

        // Attempt to parse a valid date (with slashes) from a string.
        // Check to make sure the parse was successful.
        strDate = "02/28/2023";
        booParseSuccessful = DateTime.TryParse(strDate, out datParsed);
        // datParsed = {2/28/2023 12:00:00 AM}, booParseSuccessful = true

        // Attempt to parse a valid date (written out) from a string.
        // Check to make sure the parse was successful.
        strDate = "February 28, 2023";
        booParseSuccessful = DateTime.TryParse(strDate, out datParsed);
        // datParsed = {2/28/2023 12:00:00 AM}, booParseSuccessful = true

        // Attempt to parse an invalid date from a string. Check to make
        // sure the parse was successful.
        strDate = "02-29-2023";
        booParseSuccessful = DateTime.TryParse(strDate, out datParsed);
        // datParsed = {1/1/0001 12:00:00 AM}, booParseSuccessful = false

    }

    protected void UseTimeRelatedProperties()
    {

        // Get the date and time for display.
        string strNow = DateTime.Now.ToString();
        // strNow = "3/21/2023 12:16:03 PM"

        // Declare a new DateTime structure to hold the date and time.
        DateTime datNow = new DateTime();
        // datNow = {1/1/0001 12:00:00 AM}

        // Assign the date and time to the DateTime structure.
        datNow = DateTime.Now;
        // datNow = {3/21/2023 12:16:03 AM}

        // Hardcode the current date and time.
        DateTime datCurrent = new DateTime(2023, 03, 21, 12, 16, 03);
        // datCurrent = {3/21/2023 12:16:03 PM}

        // Get the hour.
        int intHour = datCurrent.Hour;
        // intHour = 12

        // Get the minute.
        int intMinute = datCurrent.Minute;
        // intMinute = 16

        // Get the second.
        int intSecond = datCurrent.Second;
        // intSecond = 3

    }

    protected void UseTimeRelatedMethods()
    {

        // Hardcode the current date and time.
        DateTime datCurrent = new DateTime(2023, 03, 21, 12, 16, 03);
        // datCurrent = {3/21/2023 12:16:03 PM}

        // Declare a new DateTime structure to hold the new date and time.
        DateTime datNew = new DateTime();
        // datNew = {1/1/0001 12:00:00 AM}

        // Add 2 hours to the current time giving the new time.
        datNew = datCurrent.AddHours(2);
        // datNew = {3/21/2023 2:16:03 PM}

        // Add 4 minutes to the current time giving the new time.
        datNew = datCurrent.AddMinutes(4);
        // datNew = {3/21/2023 12:20:03 PM}

        // Add 6 seconds to the current time giving the new time.
        datNew = datCurrent.AddSeconds(6);
        // datNew = {3/21/2023 12:16:09 PM}

        // Compare the first date and time to the second date and time.
        // If result < 0, first date and time < second date and time.
        // If result = 0, first date and time = second date and time.
        // If result > 0, first date and time > second date and time.
        DateTime datFirst = new DateTime(2023, 03, 21, 12, 16, 03);
        DateTime datSecond = new DateTime(2023, 03, 21, 12, 16, 00);
        int intResult = datFirst.CompareTo(datSecond);
        // intResult = 1

        // Determine how many hours, minutes, and seconds have elapsed
        // since the first-of-year date and time.
        DateTime datFirstOfYear = new DateTime(2023, 01, 01, 00, 00, 00);
        TimeSpan timTimeSpan = datCurrent.Subtract(datFirstOfYear);
        double douHoursElapsed = timTimeSpan.TotalHours;
        // douHoursElapsed = 1908.2675
        double douMinutesElapsed = timTimeSpan.TotalMinutes;
        // douMinutesElapsed = 114496.05
        double douSecondsElapsed = timTimeSpan.TotalSeconds;
        // douSecondsElapsed = 6869763

    }

    protected void PerformTimeFormatting()
    {

        // Hardcode the current date and time.
        DateTime datCurrent = new DateTime(2023, 03, 21, 12, 16, 03);
        // datCurrent = {3/21/2023 12:16:03 PM}

        // Declare a time string.
        string strTime = "";
        // strTime = ""

        // Format the current time as a long time.
        strTime = datCurrent.ToLongTimeString();
        // strTime = "12:16:03 PM"

        // Format the current time as a short time.
        strTime = datCurrent.ToShortTimeString();
        // strTime = "12:16 PM"

        // Customize the current time format.
        strTime = datCurrent.ToString("HH 'Hours' mm 'Minutes' ss 'Seconds'");
        // strTime = "12 Hours 16 Minutes 03 Seconds"

    }

}