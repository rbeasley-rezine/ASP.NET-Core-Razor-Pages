﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputFileModel : PageModel
{

    private readonly IWebHostEnvironment IWebHostEnvironment;
    public InputFileModel(IWebHostEnvironment IWHE)
    {
        IWebHostEnvironment = IWHE;
    }

    public string MessageColor;
    public string Message;

    public IFormFile ProductImage { get; set; }

    public void OnGet()
    {
    }

    public void OnPostUploadProductImage()
    {

        if (ProductImage != null)
        {
            // Upload the file.
            string strImagesPath = IWebHostEnvironment.WebRootPath + "//images//";
            string strFileName = ProductImage.FileName;
            string strFilePath = strImagesPath + strFileName;
            FileStream objFileStream = new FileStream(strFilePath, FileMode.Create);
            ProductImage.CopyTo(objFileStream);
            objFileStream.Dispose();
            // Set the message.
            MessageColor = "Green";
            Message = "You have uploaded the product image successfully!";
        }
        else
        {
            // Set the message.
            MessageColor = "Red";
            Message = "Please select a product image to upload and try again.";
        }

    }

}