﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputCheckboxModel : PageModel
{

    public string MessageColor;
    public string Message;

    public bool Footwear { get; set; }
    public bool Clothing { get; set; }
    public bool Racquets { get; set; }

    public void OnGet()
    {
    }

    public void OnPostSetFilters()
    {

        // Build the message.
        if (Footwear)
        {
            Message = Message + "Footwear ";
        }
        if (Clothing)
        {
            Message = Message + "Clothing ";
        }
        if (Racquets)
        {
            Message = Message + "Racquets ";
        }

        // Set the message.
        MessageColor = "Green";
        Message = "You have chosen to filter your search on the following: " + Message;

    }

}