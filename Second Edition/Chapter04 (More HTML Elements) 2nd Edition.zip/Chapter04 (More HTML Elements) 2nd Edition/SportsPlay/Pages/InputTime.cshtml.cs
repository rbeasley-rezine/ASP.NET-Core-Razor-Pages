﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputTimeModel : PageModel
{

    public string MessageColor;
    public string Message;

    public DateTime ServiceCallTime { get; set; }

    public void OnGet()
    {
    }

    public void OnPostSelectServiceCallTime()
    {

        // Set the message.
        MessageColor = "Green";
        Message = "You have selected a service call time of " + ServiceCallTime.ToShortTimeString() + ".";

    }

}