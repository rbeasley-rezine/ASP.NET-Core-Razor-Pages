﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputHiddenModel : PageModel
{

    public string MessageColor;
    public string Message;

    public int EmployeeID { get; set; }

    public void OnGet()
    {

        // Set the employee ID.
        EmployeeID = 7;

    }

    public void OnPostDisplayEmployeeID()
    {

        // Set the message.
        MessageColor = "Green";
        Message = "You have displayed Employee ID " + EmployeeID + ".";

    }

}