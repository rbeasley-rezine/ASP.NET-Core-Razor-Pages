﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class SelectModel : PageModel
{

    public string MessageColor;
    public string Message;

    public string Supplier { get; set; }

    public void OnGet()
    {
    }

    public void OnPostDisplaySupplierPOC()
    {

        // Build the message.
        if (Supplier == "Adidas")
        {
            Message = "Alan Alte";
        }
        else if (Supplier == "Babolat")
        {
            Message = "Bill Baker";
        }
        else if (Supplier == "Head")
        {
            Message = "Hailey Hawkins";
        }

        // Set the message.
        MessageColor = "Green";
        Message = "Your point of contact for " + Supplier + " is " + Message + ".";

    }

}