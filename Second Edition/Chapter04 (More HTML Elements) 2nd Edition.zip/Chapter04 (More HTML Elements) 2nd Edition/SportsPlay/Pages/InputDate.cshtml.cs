﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputDateModel : PageModel
{

    public string MessageColor;
    public string Message;

    public DateTime ShippingDate { get; set; }

    public void OnGet()
    {
    }

    public void OnPostSelectShippingDate()
    {

        // Set the message.
        MessageColor = "Green";
        Message = "You have selected a shipping date of " + ShippingDate.ToShortDateString() + ".";

    }

}