﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

[BindProperties]
public class InputMonthModel : PageModel
{

    public string MessageColor;
    public string Message;

    public DateTime InventoryMonth { get; set; }

    public void OnGet()
    {
    }

    public void OnPostSelectInventoryMonth()
    {

        // Set the message.
        MessageColor = "Green";
        Message = "You have selected an inventory month of " + InventoryMonth.ToString("MMMM, yyyy") + ".";

    }

}