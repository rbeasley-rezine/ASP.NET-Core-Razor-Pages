﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ImgModel : PageModel
{

    public void OnGet()
    {
    }

}