﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputTextModel : PageModel
{

    public void OnGet()
    {
    }

}