﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputCheckboxModel : PageModel
{

    public void OnGet()
    {
    }

}