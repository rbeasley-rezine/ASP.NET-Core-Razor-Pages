﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputMonthModel : PageModel
{

    public void OnGet()
    {
    }

}