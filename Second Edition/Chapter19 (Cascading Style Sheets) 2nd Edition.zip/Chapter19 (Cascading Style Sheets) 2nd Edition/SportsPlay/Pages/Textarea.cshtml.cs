﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class TextareaModel : PageModel
{

    public void OnGet()
    {
    }

}