﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputRadioModel : PageModel
{

    public void OnGet()
    {
    }

}