﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputTimeModel : PageModel
{

    public void OnGet()
    {
    }

}