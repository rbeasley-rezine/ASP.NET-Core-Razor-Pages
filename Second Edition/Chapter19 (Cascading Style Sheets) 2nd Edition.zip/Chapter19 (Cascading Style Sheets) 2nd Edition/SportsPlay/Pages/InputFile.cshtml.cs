﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputFileModel : PageModel
{

    public void OnGet()
    {
    }

}