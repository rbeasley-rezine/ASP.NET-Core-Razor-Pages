﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class InputDateModel : PageModel
{

    public void OnGet()
    {
    }

}