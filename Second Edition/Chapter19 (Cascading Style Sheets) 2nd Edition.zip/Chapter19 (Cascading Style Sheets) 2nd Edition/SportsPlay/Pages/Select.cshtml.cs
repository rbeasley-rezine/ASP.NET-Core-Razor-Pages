﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class SelectModel : PageModel
{

    public void OnGet()
    {
    }

}