﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class AlertMethodModel : PageModel
{

    public void OnGet()
    {
    }

}