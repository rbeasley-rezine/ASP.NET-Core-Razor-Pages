﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ElementAttributesModel : PageModel
{

    public void OnGet()
    {
    }

}