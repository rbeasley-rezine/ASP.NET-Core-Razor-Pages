﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ConfirmMethodModel : PageModel
{

    public void OnGet()
    {
    }

}