﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class JavaScriptFileModel : PageModel
{

    public void OnGet()
    {
    }

}