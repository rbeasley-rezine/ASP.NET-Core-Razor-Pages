﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class ElementStylesModel : PageModel
{

    public void OnGet()
    {
    }

}