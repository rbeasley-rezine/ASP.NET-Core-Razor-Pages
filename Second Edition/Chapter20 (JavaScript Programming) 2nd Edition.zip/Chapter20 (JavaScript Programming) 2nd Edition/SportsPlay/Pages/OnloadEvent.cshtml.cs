﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class OnloadEventModel : PageModel
{

    public void OnGet()
    {
    }

}