﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class SwitchStructureModel : PageModel
{

    public void OnGet()
    {
    }

}