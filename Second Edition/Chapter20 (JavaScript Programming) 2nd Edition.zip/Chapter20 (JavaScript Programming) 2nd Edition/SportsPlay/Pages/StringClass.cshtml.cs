﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class StringClassModel : PageModel
{

    public void OnGet()
    {
    }

}