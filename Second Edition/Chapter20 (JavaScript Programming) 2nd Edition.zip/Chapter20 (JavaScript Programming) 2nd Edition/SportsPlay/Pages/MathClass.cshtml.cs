﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class MathClassModel : PageModel
{

    public void OnGet()
    {
    }

}