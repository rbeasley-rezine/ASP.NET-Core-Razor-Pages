﻿function ValidateRange(strValue, strErrorMessage, decMinimum, decMaximum) {

    strValue = strValue.trim();
    if (strValue != "") {
        if (!isNaN(strValue) && strValue >= decMinimum && strValue <= decMaximum) {
            return "";
        }
        else {
            var strMessage = strErrorMessage + "\n";
            return strMessage;
        }
    }
    else {
        return "";
    }

}
