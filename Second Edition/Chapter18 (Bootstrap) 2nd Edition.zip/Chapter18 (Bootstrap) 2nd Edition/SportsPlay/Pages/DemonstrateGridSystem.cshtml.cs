﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class DemonstrateGridSystemModel : PageModel
{

    public void OnGet()
    {
    }

}