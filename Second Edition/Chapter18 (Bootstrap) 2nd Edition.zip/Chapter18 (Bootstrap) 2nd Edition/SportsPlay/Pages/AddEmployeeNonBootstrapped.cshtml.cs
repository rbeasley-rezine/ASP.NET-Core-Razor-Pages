﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class AddEmployeeNonBootstrappedModel : PageModel
{

    public void OnGet()
    {
    }

}