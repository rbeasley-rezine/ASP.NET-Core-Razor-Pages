﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class AddEmployeeBootstrappedModel : PageModel
{

    public void OnGet()
    {
    }

}