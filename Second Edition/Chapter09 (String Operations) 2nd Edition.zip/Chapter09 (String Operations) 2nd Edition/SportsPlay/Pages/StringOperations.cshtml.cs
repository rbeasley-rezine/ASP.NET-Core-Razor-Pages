﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsPlay.Pages;

public class StringOperationsModel : PageModel
{

    public void OnGet()
    {

        PerformStringConcatenations();
        UseEscapeSequences();
        UseVerbatimLiterals();
        PerformStringClassOperations();

    }

    protected void PerformStringConcatenations()
    {

        // Concatenate three strings.
        string strLastName = "Billingsley";
        string strFirstName = "Beth";
        string strMiddleInitial = "B";
        string strFullName = strFirstName + " " + strMiddleInitial + " " + strLastName;
        // strFullName = "Beth B Billingsley"

        // Concatenate a string and a number.
        decimal decPrice = 199.00m;
        string strPrice = "Price: " + decPrice;
        // strPrice = "Price: 199.00"

    }

    protected void UseEscapeSequences()
    {

        // Use the new line escape sequence (\n).
        string strAddress = "6785 Barker Rd.";
        string strCity = "Bickman";
        string strState = "MS";
        string strZipCode = "68321";
        string strFullAddress = "";
        strFullAddress = strAddress + "\n" + strCity + ", " + strState + " " + strZipCode;
        // strFullAddress (displayed) = "6785 Barker Rd.
        //                               Bickman, MS 68321"

        // Use the tab escape sequence (\t).
        string strLastName1 = "Jack";
        string strFirstName1 = "Jerry";
        string strLastName2 = "Smith";
        string strFirstName2 = "Sally";
        string strNameList = strLastName1 + "\t" + strFirstName1 + "\n" + strLastName2 + "\t" + strFirstName2;
        // strNameList (displayed) = "Jack   Jerry
        //                            Smith  Sally"

        // Use the backslash escape sequence (\\).
        string strFilePath = "c:\\myfolder\\myfile.txt";
        // strFilePath (displayed) = "c:\myfolder\myfile.txt"

        // Use the quote escape sequence (\").
        string strMessage = "Please click \"Submit\" to complete your order.";
        // strMessage (displayed) = "Please click "Submit" to complete your
        // order."

    }

    protected void UseVerbatimLiterals()
    {

        // Use a verbatim literal.
        string strFilePath = @"c:\myfolder\myfile.txt";
        // strFilePath (displayed) = "c:\myfolder\myfile.txt"

        // Use a verbatim literal.
        string strMessage = @"Please click ""Submit"" to complete your order.";
        // strMessage (displayed) = "Please click "Submit" to complete your
        // order."

    }

    protected void PerformStringClassOperations()
    {

        // Get the number of characters in the string.
        string strAddress = "123 Main Street";
        int intLengthOfString = strAddress.Length;
        // intLengthOfString = 15

        // Concatenate three strings.
        string strLastName = "Billingsley";
        string strFirstName = "Beth";
        string strMiddleInitial = "B";
        string strFullName = String.Concat(strFirstName, " ", strMiddleInitial, " ", strLastName);
        // strFullName = "Beth B Billingsley"

        // Check to see if the word "unhappy" exists in the string.
        string strNotes = "Mr. Richards was unhappy with his order.";
        bool booUnhappy = strNotes.Contains("unhappy");
        // booUnhappy = true

        // Check to see if the string ends with ".jpg".
        string strImage = "NMSFA7S.jpg";
        bool booCorrectFileType = strImage.EndsWith(".jpg");
        // booCorrectFileType = true

        // Get the position of "gmail" in the string.
        string strEmailAddress = "mmyers@gmail.com";
        int intDomainLocation = strEmailAddress.IndexOf("gmail");
        // intDomainLocation = 7

        // Insert dashes into the string.
        string strPhoneOld = "1234567890";
        string strPhoneNew = "";
        strPhoneNew = strPhoneOld.Insert(3, "-");
        strPhoneNew = strPhoneNew.Insert(7, "-");
        // strPhoneNew = "123-456-7890"

        // Determine whether or not the string is null.
        string strAddress1 = null;
        string strAddress2 = "";
        string strAddress3 = "123 Main Street";
        bool booIsNull = false;
        booIsNull = String.IsNullOrEmpty(strAddress1);
        // booIsNull = true
        booIsNull = String.IsNullOrEmpty(strAddress2);
        // booIsNull = true
        booIsNull = String.IsNullOrEmpty(strAddress3);
        // booIsNull = false

        // Find the position of the last "." in the string.
        strEmailAddress = "Cecil.C.Cook@yahoo.com";
        int intLastPeriod = strEmailAddress.LastIndexOf(".");
        // intLastPeriod = 18

        // Right-align the characters in a 15 character string
        // by padding them with spaces on the left.
        string strLastNameOld = "Fredericks";
        string strLastNameNew = strLastNameOld.PadLeft(15);
        // strLastNameNew = "     Fredericks"

        // Left-align the characters in a 15 character string
        // by padding them with spaces on the right.
        strLastNameOld = "Fredericks";
        strLastNameNew = strLastNameOld.PadRight(15);
        // strLastNameNew = "Fredericks     "

        // Remove all the characters in the string beginning
        // at position 5.
        string strZipCodeOld = "12345-0000";
        string strZipCodeNew = strZipCodeOld.Remove(5);
        // strZipCodeNew = "12345"

        // Replace all the "-" in the string with "/".
        string strDateOld = "20xx-07-10";
        string strDateNew = strDateOld.Replace("-", "/");
        // strDateNew = "20xx/07/10"

        // Split up the words in the string and place them in
        // an array. The word delimiter is a space.
        string[] strSportsArray = new string[5];
        string strSports = "Basketball Football Soccer";
        strSportsArray = strSports.Split();
        // strMessageArray[0] = "Basketball"
        // strMessageArray[1] = "Football"
        // strMessageArray[2] = "Soccer"

        // Split up the words in the string and place them in
        // an array. The word delimiters are space, comma, and
        // period. Do not include any empty entries in the array.
        char[] chaSeparatorArray = new char[] { ' ', ',', '.' };
        string[] strMessageArray = new string[5];
        string strMessage = "For today's special, see below.";
        strMessageArray = strMessage.Split(chaSeparatorArray, StringSplitOptions.RemoveEmptyEntries);
        // strMessageArray[0] = "For"
        // strMessageArray[1] = "today's"
        // strMessageArray[2] = "special"
        // strMessageArray[3] = "see"
        // strMessageArray[4] = "below"

        // Check to see if the string begins with "Nike".
        string strProduct = "Nike Flare Women's Shoe";
        bool booNike = strProduct.StartsWith("Nike");
        // booNike = true

        // Extract characters from the string beginning at position
        // 5 for a length of 2.
        string strDate = "20xx-07-10";
        string strMonth = strDate.Substring(5, 2);
        // strMonth = "07"

        // Force all the characters in the string to lower case.
        string strPasswordOld = "ABC123";
        string strPasswordNew = strPasswordOld.ToLower();
        // strPasswordNew = "abc123"

        // Format the number as a string.
        decimal decPrice = 199.00m;
        string strPrice = decPrice.ToString();
        // strPrice = "199.00"

        // Format the number as currency with the specified
        // number of decimal places.
        decPrice = 199.00m;
        strPrice = decPrice.ToString("c2");
        // strPrice = "$199.00"

        // Format the number with the specified number of decimal
        // places.
        decPrice = 10.99m;
        strPrice = decPrice.ToString("f4");
        // strPrice = "10.9900"

        // Format the number with thousands separators with the
        // specified number of decimal places.
        decPrice = 1099m;
        strPrice = decPrice.ToString("n2");
        // strPrice = "1,099.00"

        // Format the number as a percentage with the specified
        // number of decimal places. Note: decNumberInStock and
        // decReorderLevel cannot be defined as integers or
        // integer division will take place, which will not
        // yield the correct result.
        decimal decNumberInStock = 9m;
        decimal decReorderLevel = 2m;
        decimal decSafetyLevel = 1 - (decReorderLevel / decNumberInStock);
        string strSafetyLevel = decSafetyLevel.ToString("p0");
        // strSafetyLevel = "78%"

        // Force all the characters in the string to upper case.
        strPasswordOld = "abc123";
        strPasswordNew = strPasswordOld.ToUpper();
        // strPasswordNew = "ABC123"

        // Remove from the string all leading and trailing blanks.
        strLastNameOld = "   Everest   ";
        strLastNameNew = strLastNameOld.Trim();
        // strLastNameNew = "Everest"

    }

}